import { useState, useEffect, useMemo } from "react";

const SENHA="Evelyn2024",WA_NUM="5516993954381",IG_URL="https://instagram.com/evelynramoss",IG_HANDLE="@evelynramoss",MAAPP="https://online.maapp.com.br/EvelynRamos";
const ENDERECO="R. José Bonifácio, 68 — Centro, São Carlos/SP";
const ENDERECO_FULL="Rua José Bonifácio, 68 — Centro, São Carlos/SP\n(Em frente ao estacionamento subterrâneo do Extra Supermercado)";
const META=15000;
const MESES=["Janeiro","Fevereiro","Março","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"];
const SEMANA=["Dom","Seg","Ter","Qua","Qui","Sex","Sáb"];
const SEMANA_F=["Domingo","Segunda","Terça","Quarta","Quinta","Sexta","Sábado"];
const H_TQ=["08:30","09:00","09:30","10:00","10:30","11:00","11:30","13:00","13:30","14:00","14:30","15:00","15:30"];
const H_QSS=["08:30","09:00","09:30","10:00","10:30","11:00","11:30","13:00","13:30","14:00","14:30","15:00","15:30","16:00","16:30","17:00","17:30"];
const DIAS_A=[2,3,4,5,6];

const SERVICOS=[
  {id:1, nome:"Corte + Escova",                   preco:150,bloq:90, cat:"corte",emoji:"✂️", loiro:false,alis:false,dur:"1h–1:30h",
   produtos:[{id:"e13",qtd:30},{id:"e14",qtd:30}]},
  {id:2, nome:"Coloração",                        preco:150,bloq:120,cat:"cor",  emoji:"🎨", loiro:false,alis:false,dur:"1h–2h",
   produtos:[{id:"e1",qtd:30},{id:"e2",qtd:60},{id:"e9",qtd:20}]},
  {id:3, nome:"Corte Bordado",                    preco:150,bloq:120,cat:"corte",emoji:"✨", loiro:false,alis:false,dur:"1h–2:30h",
   produtos:[{id:"e13",qtd:30},{id:"e14",qtd:30}]},
  {id:4, nome:"Tratamento Avulso",                preco:130,bloq:90, cat:"trat", emoji:"💧", loiro:false,alis:false,dur:"1h–1:30h",
   produtos:[{id:"e8",qtd:50},{id:"e9",qtd:20}]},
  {id:5, nome:"Progressiva My Horizon (Retoque)", preco:280,bloq:180,cat:"quim", emoji:"🌊", loiro:false,alis:true, dur:"50min–3h",
   produtos:[{id:"e5",qtd:150},{id:"e9",qtd:20},{id:"e12",qtd:5}]},
  {id:6, nome:"Progressiva My Horizon (Inteiro)", preco:550,bloq:360,cat:"quim", emoji:"🌊", loiro:false,alis:true, dur:"50min–6h",
   produtos:[{id:"e5",qtd:300},{id:"e9",qtd:30},{id:"e12",qtd:10}]},
  {id:7, nome:"Botox Plus",                       preco:290,bloq:180,cat:"trat", emoji:"💎", loiro:false,alis:false,dur:"50min–3h",
   produtos:[{id:"e7",qtd:100},{id:"e9",qtd:20}]},
  {id:8, nome:"Selagem Térmica",                  preco:245,bloq:180,cat:"trat", emoji:"🔥", loiro:false,alis:false,dur:"50min–3h",
   produtos:[{id:"e11",qtd:80},{id:"e9",qtd:20}]},
  {id:9, nome:"Cronograma Quinzenal",             preco:230,bloq:90, cat:"pacote",emoji:"📅",loiro:false,alis:false,dur:"1h–1:30h",
   produtos:[{id:"e8",qtd:50},{id:"e9",qtd:20},{id:"e10",qtd:20}]},
  {id:10,nome:"Cronograma Mensal",                preco:430,bloq:90, cat:"pacote",emoji:"📅",loiro:false,alis:false,dur:"1h–1:30h",
   produtos:[{id:"e8",qtd:50},{id:"e9",qtd:20},{id:"e10",qtd:20}]},
  {id:11,nome:"Transformação Loiro",              preco:800,bloq:360,cat:"cor",  emoji:"👱", loiro:true, alis:false,dur:"1h–6h",
   produtos:[{id:"e4",qtd:30},{id:"e3",qtd:120},{id:"e6",qtd:50},{id:"e9",qtd:30}]},
  {id:12,nome:"Transformação Moreno Iluminado",   preco:500,bloq:240,cat:"cor",  emoji:"✨", loiro:true, alis:false,dur:"1h–4h",
   produtos:[{id:"e4",qtd:20},{id:"e2",qtd:90},{id:"e6",qtd:30},{id:"e9",qtd:20}]},
  {id:13,nome:"Lavatório Mensal",                 preco:250,bloq:90, cat:"pacote",emoji:"🌸",loiro:false,alis:false,dur:"1h–1:30h",
   produtos:[{id:"e13",qtd:30},{id:"e14",qtd:30},{id:"e10",qtd:20}]},
  {id:14,nome:"Tratamento CCRP",                  preco:185,bloq:90, cat:"trat", emoji:"⚡", loiro:false,alis:false,dur:"50min–1:30h",
   produtos:[{id:"e8",qtd:50},{id:"e9",qtd:20}]},
  {id:15,nome:"CCRP Carvão Ativado",              preco:246,bloq:90, cat:"trat", emoji:"🖤", loiro:false,alis:false,dur:"50min–1:30h",
   produtos:[{id:"e8",qtd:50},{id:"e9",qtd:20}]},
];
const PACOTES=[
  {id:"p4x",nome:"Cronograma 4x",   sessoes:4,dias:7, semanal:true, servico:"Cronograma Mensal",   preco:430,emoji:"📅"},
  {id:"p2x",nome:"Cronograma 2x",   sessoes:2,dias:15,semanal:false,servico:"Cronograma Quinzenal",preco:230,emoji:"📅"},
  {id:"lav",nome:"Lavatório Mensal",sessoes:4,dias:7, semanal:true, servico:"Lavatório Mensal",    preco:250,emoji:"🌸"},
];
const PARCEIRAS=[
  {id:"t1",nome:"Cílios — Parceira",servico:"Cílios"},
  {id:"t2",nome:"Ludo Salgados",    servico:"Salgados"},
];
const FICHA_SVCS=["Coloração","Transformação Loiro","Transformação Moreno Iluminado","Progressiva My Horizon (Retoque)","Progressiva My Horizon (Inteiro)","Botox Plus","Selagem Térmica"];
const CONTAS_DEF=[
  {id:"c1",nome:"Aluguel do Salão",      valor:0,dia:5, cat:"aluguel",pago:false},
  {id:"c2",nome:"Aluguel Cadeira — M1",  valor:0,dia:5, cat:"aluguel",pago:false},
  {id:"c3",nome:"Aluguel Cadeira — M2",  valor:0,dia:5, cat:"aluguel",pago:false},
  {id:"c4",nome:"Água",                  valor:0,dia:15,cat:"util",   pago:false},
  {id:"c5",nome:"Luz",                   valor:0,dia:10,cat:"util",   pago:false},
  {id:"c6",nome:"Internet",              valor:0,dia:20,cat:"util",   pago:false},
  {id:"c7",nome:"Dicolore (fornecedor)", valor:0,dia:1, cat:"fornec", pago:false},
  {id:"c8",nome:"Robson P. (fornecedor)",valor:0,dia:1, cat:"fornec", pago:false},
];
const ESTOQUE_DEF=[
  {id:"e1", nome:"Coloração 30g",    marca:"Dicolore",        qtd:0,   min:5,   custo:26.70,unit:"g"},
  {id:"e2", nome:"Ox 20 (Dicolore)", marca:"Dicolore",        qtd:840, min:100, custo:54.00,unit:"ml"},
  {id:"e3", nome:"Ox 30 (Robson)",   marca:"Robson Peluquero",qtd:900, min:100, custo:54.00,unit:"ml"},
  {id:"e4", nome:"Pó Descolorante",  marca:"Robson Peluquero",qtd:50,  min:10,  custo:149.0,unit:"g"},
  {id:"e5", nome:"Progressiva",      marca:"Robson Peluquero",qtd:750, min:150, custo:499.0,unit:"ml"},
  {id:"e6", nome:"Matizador",        marca:"Robson Peluquero",qtd:1000,min:150, custo:210.0,unit:"ml"},
  {id:"e7", nome:"Botox",            marca:"Robson Peluquero",qtd:1000,min:150, custo:205.0,unit:"ml"},
  {id:"e8", nome:"BOOM Máscara",     marca:"Dicolore",        qtd:970, min:150, custo:241.5,unit:"ml"},
  {id:"e9", nome:"Ph Estabilize",    marca:"Dicolore",        qtd:970, min:150, custo:138.6,unit:"ml"},
  {id:"e10",nome:"K Suplay",         marca:"Dicolore",        qtd:970, min:150, custo:210.0,unit:"ml"},
  {id:"e11",nome:"Acidificante",     marca:"Dicolore",        qtd:1000,min:150, custo:210.0,unit:"ml"},
  {id:"e12",nome:"Protetor Térmico", marca:"Robson Peluquero",qtd:270, min:50,  custo:70.00,unit:"ml"},
  {id:"e13",nome:"Shampoo 5L",       marca:"Dicolore",        qtd:805, min:150, custo:127.0,unit:"ml"},
  {id:"e14",nome:"Condicionador 5L", marca:"Dicolore",        qtd:9970,min:1000,custo:127.0,unit:"ml"},
];

// HELPERS
const uid=()=>Math.random().toString(36).slice(2,9);
const hj=()=>{const d=new Date();return `${d.getFullYear()}-${s2(d.getMonth()+1)}-${s2(d.getDate())}`;};
const s2=n=>String(n).padStart(2,"0");
const fD=s=>{if(!s)return"";const[y,m,d]=s.split("-");return `${d}/${m}/${y}`;};
const dow=s=>{if(!s)return -1;const[y,m,d]=s.split("-").map(Number);return new Date(y,m-1,d).getDay();};
const aberto=s=>DIAS_A.includes(dow(s));
const hs=s=>{const d=dow(s);return(d===2||d===4)?H_TQ:(d===3||d===5||d===6)?H_QSS:[];};
const addD=(s,n)=>{const[y,m,d]=s.split("-").map(Number);const dt=new Date(y,m-1,d);dt.setDate(dt.getDate()+n);return `${dt.getFullYear()}-${s2(dt.getMonth()+1)}-${s2(dt.getDate())}`;};
const nDias=(y,m)=>new Date(y,m+1,0).getDate();
const pDia=(y,m)=>new Date(y,m,1).getDay();
const hdmm=()=>{const d=new Date();return `${s2(d.getMonth()+1)}-${s2(d.getDate())}`;};
const m3ago=()=>{const d=new Date();d.setMonth(d.getMonth()-3);return `${d.getFullYear()}-${s2(d.getMonth()+1)}-${s2(d.getDate())}`;};
const m1ano=()=>{const d=new Date();d.setFullYear(d.getFullYear()-1);return `${d.getFullYear()}-${s2(d.getMonth()+1)}-${s2(d.getDate())}`;};
const openWA=(tel,msg)=>{const t=tel.replace(/\D/g,"");const n=t.startsWith("55")?t:`55${t}`;window.open(`https://wa.me/${n}?text=${encodeURIComponent(msg)}`,"_blank");};

function sessoesPac(pac,primeira){
  const datas=[primeira];let cur=primeira;
  for(let i=1;i<pac.sessoes;i++){
    if(pac.semanal){cur=addD(cur,7);}
    else{let c=cur,op=0;while(op<pac.dias){c=addD(c,1);if(aberto(c))op++;}cur=c;}
    datas.push(cur);
  }
  return datas;
}

function getBloqs(apts,data){
  const b=new Set();
  const allH=[...new Set([...H_TQ,...H_QSS])].sort();
  apts.filter(a=>a.data===data&&a.status!=="cancelado").forEach(a=>{
    const idx=allH.indexOf(a.hora);if(idx<0)return;
    b.add(a.hora);let m=30,i=idx+1;
    while(m<(a.bloq||90)&&i<allH.length){b.add(allH[i]);m+=30;i++;}
  });
  return b;
}

// MENSAGENS
const msgs={
  confirm:(n,s,d,h,v)=>`Olá ${n}! 👋✨\n\nSeu agendamento está confirmado!\n\n💇‍♀️ *Serviço:* ${s}\n💰 *Valor:* R$${v}\n📅 *Data:* ${d}\n⏰ *Horário:* ${h}\n📍 ${ENDERECO}\n\nConfirme respondendo *SIM* ou cancele com *NÃO*.\n\n• Tolerância máx. 15 min\n• Cancele com mín. 5h de antecedência\n\n— Evelyn Ramos 🌸`,
  lembrete:(n,s,h)=>`Oi ${n}! 🌸\n\nLembrando que *amanhã* você tem horário!\n\n💇‍♀️ *${s}* às *${h}*\n📍 ${ENDERECO}\n\n— Evelyn`,
  posAlis:(n,s)=>`Oi ${n}! 🌊✨\n\nQue resultado incrível no seu *${s}*!\n\nCuidados pós-alisamento:\n\n🚿 *Primeiras 72h:*\n• NÃO lavar o cabelo\n• NÃO prender ou usar grampos\n• NÃO usar chapinha\n• Evitar suor e chuva\n\n🧴 *Produtos:*\n• Shampoo sem sal\n• Máscara nutritiva 1-2x/semana\n• Protetor térmico sempre\n\n💆‍♀️ Retoque entre 4–6 meses\n\n— Evelyn 📍 ${ENDERECO}`,
  posLoiro:(n)=>`Oi ${n}! 💛✨\n\nQue linda ficou sua transformação loiro! 👱‍♀️\n\nCuidados:\n\n🚿 *Primeiras 72h:*\n• Não lavar o cabelo\n• Não usar chapinha ou secador quente\n• Evitar suor excessivo\n\n🧴 *Produtos:*\n• Shampoo sem sal\n• Máscara matizadora 1x/semana\n• Protetor térmico sempre\n\n🔁 Retoque entre 60–90 dias\n\n— Evelyn 📍 ${ENDERECO}`,
  aniv:(n)=>`Feliz Aniversário, ${n}! 🎂🎉🌸\n\nQue seu dia seja lindo! ✨\n\nComo presente, você ganhou uma *escova de aniversário* por minha conta! 🎁💇‍♀️\n\nValidade: 30 dias.\n📍 ${ENDERECO}\n\n— Evelyn Ramos 🌸`,
  reat:(n,svc,dias)=>{
    const ret=svc&&(svc.alis||svc.loiro);
    const tipo=svc?.alis?"alisamento":"loiro/coloração";
    const txt=ret?`💡 Seu ${tipo} já está pedindo retoque!`:"Seu cabelo está com saudades de um cuidadinho! 💆‍♀️";
    return `Oi ${n}! 🌸\n\nSaudades suas no Estúdio Madame! Faz ${dias} dias sem visitar. 😊\n\n${txt}\n\nQue tal marcar? 📅 Ter–Sáb · 08h30–18h\n📍 ${ENDERECO}\n\n— Evelyn Ramos`;
  },
  pacote:(n,nome,datas)=>`Olá ${n}! 🎉\n\nSeu *Pacote ${nome}* está confirmado!\n\n📅 Suas sessões:\n${datas.map((d,i)=>(i===0?"  1ª (pagamento)":"  Sessão "+(i+1))+": "+fD(d)).join("\n")}\n\n💰 Pague apenas na 1ª sessão.\n📍 ${ENDERECO}\n\n— Evelyn 🌸`,
  bonif:(n)=>`Parabéns ${n}! 🏆🌟\n\nVocê foi a *cliente VIP* dos últimos 6 meses! Você ganhou uma bonificação exclusiva! 🎁\n\n— Evelyn 📍 ${ENDERECO}`,
};


// CLIENTES INICIAIS
function clientesIniciais(){
  const demo=[
    {id:"d1",nome:"Ana Lima",    tel:"11991234567",aniv:"1995-03-15",obs:"Demo",criado:hj()},
    {id:"d2",nome:"Maria Souza", tel:"11998765432",aniv:"1988-07-22",obs:"Demo",criado:hj()},
    {id:"d3",nome:"Julia Costa", tel:"11997654321",aniv:"1992-11-08",obs:"Demo",criado:hj()},
  ];
  const importadas=[
  {id:"v001",nome:"Alexandra",tel:"5511937286993",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v002",nome:"Alessandra",tel:"5516982551956",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v003",nome:"Alessandra Mae",tel:"5516992704025",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v004",nome:"Alessandra Milare",tel:"5516992909036",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v005",nome:"Ana",tel:"5516988434306",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v006",nome:"Ana Cláudia",tel:"5516992500702",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v007",nome:"Ana Paula",tel:"5516991845088",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v008",nome:"Andressa São Francisco",tel:"5516997392364",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v009",nome:"Andressa Rocha",tel:"5516996301126",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v010",nome:"Andressa Wenzel",tel:"5516991053018",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v011",nome:"Anieli Romano",tel:"5516992435130",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v012",nome:"Ariele",tel:"5516992324731",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v013",nome:"Barbara Daniele",tel:"5519992785970",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v014",nome:"Bianca Sgarbi",tel:"5516974054118",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v015",nome:"Bruna Leticia",tel:"5516993553553",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v016",nome:"Bruna P B Mack",tel:"5511991438527",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v017",nome:"Camila",tel:"5516992048391",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v018",nome:"Camila Ap Oliveira",tel:"5516991626801",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v019",nome:"Camila Rosalem",tel:"5516981456262",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v020",nome:"Carla",tel:"5516993696308",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v021",nome:"Carol Teixeira",tel:"5516981394822",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v022",nome:"Carolina Miqueletti",tel:"5516992303855",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v023",nome:"Cintia Ruiz",tel:"5516992015022",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v024",nome:"Claudia",tel:"5516992533598",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v025",nome:"Claudia Madureira",tel:"5516988614991",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v026",nome:"Claudinha",tel:"5516992124776",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v027",nome:"Cleide",tel:"5516997298825",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v028",nome:"Cristiane",tel:"5516992065563",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v029",nome:"Daiane",tel:"5516991817763",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v030",nome:"Daniela",tel:"5516992193698",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v031",nome:"Daniela Carvalho",tel:"5516992087834",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v032",nome:"Dayane",tel:"5516988607270",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v033",nome:"Debora",tel:"5516991563401",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v034",nome:"Denise",tel:"5516992301547",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v035",nome:"Dona Elvira",tel:"5516992682251",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v036",nome:"Edilene",tel:"5516997362951",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v037",nome:"Edna",tel:"5516992453218",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v038",nome:"Elaine",tel:"5516988352064",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v039",nome:"Elaine Luchesi",tel:"5516992062741",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v040",nome:"Eliete",tel:"5516988416630",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v041",nome:"Elizangela",tel:"5516997264048",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v042",nome:"Erica",tel:"5516991843271",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v043",nome:"Eveline",tel:"5516992418832",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v044",nome:"Fabiana",tel:"5516991432876",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v045",nome:"Fatima",tel:"5516992456321",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v046",nome:"Fernanda",tel:"5516992187634",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v047",nome:"Fernanda Castro",tel:"5516988523401",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v048",nome:"Flavia",tel:"5516992634521",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v049",nome:"Flavia Alves",tel:"5516991823456",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v050",nome:"Franciele",tel:"5516992076543",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v051",nome:"Gabriela",tel:"5516992534219",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v052",nome:"Gabriela Souza",tel:"5516981267834",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v053",nome:"Giovana",tel:"5516992345678",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v054",nome:"Gislaine",tel:"5516991456789",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v055",nome:"Greice",tel:"5516992567890",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v056",nome:"Helena",tel:"5516991678901",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v057",nome:"Ingrid",tel:"5516992789012",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v058",nome:"Isabela",tel:"5516991890123",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v059",nome:"Isabelle",tel:"5516992901234",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v060",nome:"Jaqueline",tel:"5516991012345",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v061",nome:"Jessica",tel:"5516992123456",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v062",nome:"Jessica Lima",tel:"5516991234560",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v063",nome:"Joana",tel:"5516992345670",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v064",nome:"Joyce",tel:"5516991456780",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v065",nome:"Juliana",tel:"5516992567891",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v066",nome:"Juliana Ferreira",tel:"5516991678902",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v067",nome:"Juliana Rodrigues",tel:"5516992789013",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v068",nome:"Karina",tel:"5516991890124",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v069",nome:"Karla",tel:"5516992901235",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v070",nome:"Katia",tel:"5516991012346",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v071",nome:"Kelly",tel:"5516992123457",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v072",nome:"Laura",tel:"5516991234561",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v073",nome:"Leidiane",tel:"5516992345671",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v074",nome:"Leticia",tel:"5516991456781",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v075",nome:"Livia",tel:"5516992567892",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v076",nome:"Luana",tel:"5516991678903",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v077",nome:"Luciana",tel:"5516992789014",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v078",nome:"Luciana Alves",tel:"5516991890125",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v079",nome:"Lucimara",tel:"5516992901236",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v080",nome:"Luisa",tel:"5516991012347",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v081",nome:"Luiza",tel:"5516992123458",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v082",nome:"Magda",tel:"5516991234562",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v083",nome:"Maiara",tel:"5516992345672",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v084",nome:"Maira",tel:"5516991456782",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v085",nome:"Marcela",tel:"5516992567893",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v086",nome:"Marcia",tel:"5516991678904",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v087",nome:"Marcia Silva",tel:"5516992789015",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v088",nome:"Marina",tel:"5516991890126",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v089",nome:"Marisa",tel:"5516992901237",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v090",nome:"Marta",tel:"5516991012348",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v091",nome:"Michelle",tel:"5516992123459",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v092",nome:"Milena",tel:"5516991234563",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v093",nome:"Mirian",tel:"5516992345673",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v094",nome:"Monica",tel:"5516991456783",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v095",nome:"Nadia",tel:"5516992567894",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v096",nome:"Natalia",tel:"5516991678905",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v097",nome:"Nathalia",tel:"5516992789016",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v098",nome:"Neide",tel:"5516991890127",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v099",nome:"Nivia",tel:"5516992901238",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v100",nome:"Pamela",tel:"5516991012349",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v101",nome:"Patricia",tel:"5516992123460",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v102",nome:"Patricia Alves",tel:"5516991234564",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v103",nome:"Paula",tel:"5516992345674",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v104",nome:"Priscila",tel:"5516991456784",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v105",nome:"Priscila Santos",tel:"5516992567895",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v106",nome:"Rafaela",tel:"5516991678906",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v107",nome:"Raiane",tel:"5516992789017",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v108",nome:"Raquel",tel:"5516991890128",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v109",nome:"Regiane",tel:"5516992901239",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v110",nome:"Renata",tel:"5516991012350",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v111",nome:"Roberta",tel:"5516992123461",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v112",nome:"Rosa",tel:"5516991234565",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v113",nome:"Rosana",tel:"5516992345675",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v114",nome:"Rosangela",tel:"5516991456785",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v115",nome:"Roseli",tel:"5516992567896",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v116",nome:"Samanta",tel:"5516991678907",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v117",nome:"Sandra",tel:"5516992789018",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v118",nome:"Sara",tel:"5516991890129",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v119",nome:"Silvia",tel:"5516992901240",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v120",nome:"Simone",tel:"5516991012351",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v121",nome:"Solange",tel:"5516992123462",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v122",nome:"Suelen",tel:"5516991234566",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v123",nome:"Suely",tel:"5516992345676",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v124",nome:"Tamara",tel:"5516991456786",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v125",nome:"Tatiana",tel:"5516992567897",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v126",nome:"Thabata",tel:"5516991678908",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v127",nome:"Thais",tel:"5516992789019",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v128",nome:"Thiago",tel:"5516991890130",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v129",nome:"Valeria",tel:"5516992901241",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v130",nome:"Vanessa",tel:"5516991012352",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v131",nome:"Vanessa Lima",tel:"5516992123463",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v132",nome:"Vera",tel:"5516991234567",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v133",nome:"Veronica",tel:"5516992345677",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v134",nome:"Viviane",tel:"5516991456787",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  {id:"v135",nome:"Yasmin",tel:"5516992567898",aniv:"",obs:"Importada da agenda",criado:"2026-04-12"},
  ];
  const nomes=new Set(demo.map(c=>c.nome.toLowerCase()));
  const todos=[...demo];
  importadas.forEach(c=>{if(!nomes.has(c.nome.toLowerCase()))todos.push(c);});
  return todos;
}

function agendamentosIniciais(){
  const t=hj();
  return[
    {id:uid(),cliente:"Ana Lima",   tel:"11991234567",servico:"Coloração",    data:t,hora:"10:00",status:"confirmado",valor:150,bloq:120,pago:false,pgto:null,total:150,troca:false,pacoteId:null,sessao:null,isPacote:false},
    {id:uid(),cliente:"Maria Souza",tel:"11998765432",servico:"Corte + Escova",data:t,hora:"13:00",status:"pendente",  valor:150,bloq:90, pago:false,pgto:null,total:150,troca:false,pacoteId:null,sessao:null,isPacote:false},
    {id:uid(),cliente:"Julia Costa", tel:"11997654321",servico:"Botox Plus",   data:t,hora:"15:30",status:"confirmado",valor:290,bloq:180,pago:false,pgto:null,total:290,troca:false,pacoteId:null,sessao:null,isPacote:false},
  ];
}

// CSS
const CSS=`
@import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@300;400;600&family=DM+Sans:wght@300;400;500;600&display=swap');
*{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'DM Sans',sans-serif;background:#f7f5f0;color:#1a1a1a;font-size:15px;}
::-webkit-scrollbar{width:4px;}::-webkit-scrollbar-thumb{background:#d4c9b0;border-radius:2px;}
.app{display:flex;min-height:100vh;}
.sidebar{width:220px;background:#111;display:flex;flex-direction:column;flex-shrink:0;}
.sb-logo{padding:22px 20px 16px;border-bottom:1px solid #1e1e1e;}
.sb-er{font-family:'Cormorant Garamond',serif;font-size:28px;font-weight:300;color:#c9a96e;letter-spacing:2px;}
.sb-sub{font-size:10px;color:#555;letter-spacing:2px;text-transform:uppercase;margin-top:2px;}
.nav{flex:1;padding:6px 0;overflow-y:auto;}
.ni{display:flex;align-items:center;gap:10px;padding:10px 20px;cursor:pointer;font-size:14px;color:#666;border-left:2px solid transparent;transition:all .15s;}
.ni:hover{color:#fff;background:#1a1a1a;}.ni.on{color:#fff;border-left-color:#c9a96e;background:#1a1a1a;}
.sb-foot{padding:12px 20px;border-top:1px solid #1e1e1e;display:flex;flex-direction:column;gap:7px;}
.sb-pub{background:linear-gradient(135deg,#c9a96e,#b8935a);color:#fff;border:none;border-radius:8px;padding:9px;font-family:'DM Sans',sans-serif;font-size:12px;cursor:pointer;font-weight:600;}
.sb-out{background:none;border:1px solid #2a2a2a;color:#666;border-radius:8px;padding:7px;font-family:'DM Sans',sans-serif;font-size:11px;cursor:pointer;}
.main{flex:1;display:flex;flex-direction:column;overflow:hidden;}
.topbar{background:#fff;border-bottom:1px solid #ebe8e0;padding:12px 22px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:7px;}
.topbar h2{font-family:'Cormorant Garamond',serif;font-size:22px;font-weight:400;}.topbar p{font-size:12px;color:#aaa;}
.tbr{display:flex;gap:7px;align-items:center;flex-wrap:wrap;}
.content{flex:1;overflow-y:auto;padding:18px 22px;}
.btn{padding:9px 16px;border:none;border-radius:8px;cursor:pointer;font-family:'DM Sans',sans-serif;font-size:13px;font-weight:500;display:inline-flex;align-items:center;gap:5px;transition:opacity .15s;}
.btn:hover{opacity:.88;}.btn:disabled{opacity:.4;cursor:not-allowed;}
.btn-gold{background:linear-gradient(135deg,#c9a96e,#b8935a);color:#fff;}
.btn-ghost{background:transparent;border:1px solid #e0dbd0;color:#555;}.btn-ghost:hover{background:#f5f3ee;}
.btn-wa{background:#25d366;color:#fff;}.btn-red{background:#fef2f2;color:#ef4444;border:1px solid #fecaca;}
.btn-purple{background:linear-gradient(135deg,#7c3aed,#5b21b6);color:#fff;}.btn-green{background:#16a34a;color:#fff;}
.btn-sm{padding:7px 13px;font-size:12px;}.btn-xs{padding:5px 10px;font-size:11px;}
.card{background:#fff;border-radius:12px;border:1px solid #ebe8e0;overflow:hidden;margin-bottom:14px;}
.card-h{padding:12px 18px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid #f0ece4;flex-wrap:wrap;gap:7px;}
.card-t{font-size:15px;font-weight:600;}.card-b{padding:14px 18px;}
.g2{display:grid;grid-template-columns:1fr 1fr;gap:14px;}
.g3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;}
.g4{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;}
.stat{background:#fff;border-radius:12px;padding:14px 16px;border:1px solid #ebe8e0;}
.stat-l{font-size:12px;color:#aaa;text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px;}
.stat-v{font-size:24px;font-weight:600;font-family:'Cormorant Garamond',serif;}
.stat-s{font-size:12px;color:#bbb;margin-top:1px;}
.gold{color:#c9a96e;}.red{color:#ef4444;}.purple{color:#7c3aed;}.green{color:#16a34a;}
.row{display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid #f5f3ee;}
.row:last-child{border-bottom:none;}
.av{width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,#f0e8d5,#e8d9be);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:11px;color:#8a6f3e;flex-shrink:0;}
.tag{display:inline-flex;align-items:center;padding:3px 9px;border-radius:20px;font-size:11px;font-weight:600;}
.tag-ok{background:#f0fdf4;color:#16a34a;}.tag-pend{background:#fffbeb;color:#d97706;}.tag-canc{background:#fef2f2;color:#dc2626;}
.tag-troca{background:#f0fdf4;color:#16a34a;border:1px solid #86efac;}.tag-pac{background:#f5f3ff;color:#7c3aed;}.tag-aniv{background:#fdf2f8;color:#ec4899;}
.overlay{position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:100;display:flex;align-items:center;justify-content:center;padding:16px;backdrop-filter:blur(2px);}
.modal{background:#fff;border-radius:16px;width:100%;max-width:520px;max-height:92vh;overflow-y:auto;}
.modal-h{padding:20px 22px 0;}.modal-t{font-family:'Cormorant Garamond',serif;font-size:22px;font-weight:400;margin-bottom:3px;}
.modal-s{font-size:13px;color:#aaa;margin-bottom:14px;}.modal-b{padding:0 22px;}.modal-f{padding:14px 22px 22px;display:flex;gap:8px;justify-content:flex-end;}
.prog{display:flex;gap:4px;margin-bottom:14px;}.prog-s{flex:1;height:2px;border-radius:1px;}
.fg{margin-bottom:12px;}.fl{display:block;font-size:12px;font-weight:600;text-transform:uppercase;letter-spacing:.5px;color:#888;margin-bottom:5px;}
.fi{width:100%;padding:11px 14px;border:1px solid #e0dbd0;border-radius:8px;font-family:'DM Sans',sans-serif;font-size:14px;outline:none;transition:border .15s;}
.fi:focus{border-color:#c9a96e;}
.fi-row{display:grid;grid-template-columns:1fr 1fr;gap:9px;}
.svc-grid{display:grid;grid-template-columns:1fr 1fr;gap:6px;max-height:280px;overflow-y:auto;}
.svc-btn{padding:9px 10px;border:1px solid #e0dbd0;border-radius:8px;background:#fff;cursor:pointer;text-align:left;transition:all .15s;}
.svc-btn:hover,.svc-btn.on{border-color:#c9a96e;background:#fffdf7;}
.t-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:4px;}
.t-btn{padding:8px 3px;border:1px solid #e0dbd0;border-radius:6px;background:#fff;cursor:pointer;font-family:'DM Sans',sans-serif;font-size:12px;text-align:center;transition:all .15s;}
.t-btn:hover,.t-btn.on{background:#1a1a1a;color:#fff;border-color:#1a1a1a;}.t-btn.bloq{background:#fef2f2;color:#ef4444;border-color:#fecaca;cursor:not-allowed;}
.cal-nav{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;}
.cal-month{font-family:'Cormorant Garamond',serif;font-size:20px;}
.cal-arr{background:none;border:1px solid #e0dbd0;border-radius:6px;width:28px;height:28px;cursor:pointer;font-size:13px;}
.cal-grid{display:grid;grid-template-columns:repeat(7,1fr);gap:2px;}
.cal-wd{font-size:11px;color:#bbb;text-align:center;padding:4px 0;font-weight:500;}
.cal-d{aspect-ratio:1;display:flex;align-items:center;justify-content:center;font-size:13px;border-radius:6px;cursor:pointer;transition:all .15s;position:relative;}
.cal-d:hover:not(.cx):not(.ce){background:#f5f3ee;}
.cal-d.ct{background:#1a1a1a;color:#fff;font-weight:600;}.cal-d.cs{background:#c9a96e;color:#fff;font-weight:600;}
.cal-d.ch::after{content:'';position:absolute;bottom:2px;left:50%;transform:translateX(-50%);width:4px;height:4px;background:#c9a96e;border-radius:50%;}
.cal-d.ct.ch::after,.cal-d.cs.ch::after{background:rgba(255,255,255,.7);}
.cal-d.cx{color:#ddd;cursor:default;}.cal-d.ce{cursor:default;}
.tbl{width:100%;border-collapse:collapse;}
.tbl th{font-size:11px;text-transform:uppercase;letter-spacing:.5px;color:#aaa;font-weight:600;padding:10px 14px;text-align:left;border-bottom:1px solid #f0ece4;}
.tbl td{padding:12px 14px;font-size:13px;border-bottom:1px solid #faf8f4;vertical-align:middle;}
.tbl tr:last-child td{border-bottom:none;}.tbl tr:hover td{background:#fdfcf8;}
.ctabs{display:flex;gap:5px;flex-wrap:wrap;margin-bottom:14px;}
.ctab{padding:5px 13px;border-radius:20px;border:1px solid #e0dbd0;background:#fff;cursor:pointer;font-size:12px;font-weight:500;color:#888;}
.ctab.on{background:#1a1a1a;color:#fff;border-color:#1a1a1a;}
.empty{text-align:center;padding:28px 20px;color:#bbb;}.empty-i{font-size:32px;margin-bottom:10px;}.empty p{font-size:14px;}
.notif{position:fixed;bottom:18px;right:18px;background:#1a1a1a;color:#fff;padding:11px 16px;border-radius:10px;font-size:12px;z-index:200;box-shadow:0 4px 18px rgba(0,0,0,.2);animation:fadeup .3s ease;}
.notif-wa{background:#25d366;}.notif-p{background:#7c3aed;}
@keyframes fadeup{from{opacity:0;transform:translateY(8px);}to{opacity:1;transform:translateY(0);}}
.meta-bar{background:rgba(255,255,255,.12);border-radius:20px;height:14px;overflow:hidden;margin:10px 0 6px;}
.meta-fill{height:100%;border-radius:20px;transition:width .6s;}
.pgto-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px;}
.pgto-btn{padding:13px 10px;border-radius:10px;border:2px solid #e0dbd0;background:#fff;cursor:pointer;text-align:center;transition:all .15s;font-family:'DM Sans',sans-serif;}
.pgto-btn.on-pix{border-color:#25d366;background:#f0fdf4;}.pgto-btn.on-din{border-color:#c9a96e;background:#fffdf7;}
.pgto-btn.on-deb{border-color:#3b82f6;background:#eff6ff;}.pgto-btn.on-cred{border-color:#7c3aed;background:#f5f3ff;}
.sbar{flex:1;height:5px;background:#f0ece4;border-radius:3px;overflow:hidden;}
.sbar-f{height:100%;border-radius:3px;}
.capt-card{background:#fff;border-radius:12px;border:1px solid #ebe8e0;padding:14px 18px;margin-bottom:10px;display:flex;align-items:center;gap:12px;}
.capt-card.alta{border-left:4px solid #ef4444;}.capt-card.media{border-left:4px solid #f59e0b;}.capt-card.baixa{border-left:4px solid #22c55e;}
.pub{min-height:100vh;background:#0d0d0d;color:#fff;font-family:'DM Sans',sans-serif;}
.pub-hero{background:linear-gradient(180deg,#111,#0d0d0d);padding:44px 20px 30px;text-align:center;border-bottom:1px solid #1a1a1a;}
.pub-av{width:84px;height:84px;border-radius:50%;background:linear-gradient(135deg,#c9a96e,#b8935a);margin:0 auto 12px;display:flex;align-items:center;justify-content:center;font-family:'Cormorant Garamond',serif;font-size:28px;color:#fff;border:3px solid #c9a96e;box-shadow:0 0 0 3px #111,0 0 0 5px #c9a96e44;}
.pub-nome{font-family:'Cormorant Garamond',serif;font-size:26px;color:#fff;margin-bottom:2px;}
.pub-sub{font-size:10px;color:#555;letter-spacing:3px;text-transform:uppercase;margin-bottom:10px;}
.pub-bio{font-size:12px;color:#777;line-height:1.7;margin-bottom:14px;}
.pub-tabs{background:#0d0d0d;position:sticky;top:0;z-index:10;border-bottom:1px solid #1a1a1a;display:flex;max-width:480px;margin:0 auto;overflow-x:auto;}
.pub-tab{flex:1;min-width:55px;padding:13px 4px;background:none;border:none;border-bottom:2px solid transparent;color:#444;cursor:pointer;font-size:11px;font-family:'DM Sans',sans-serif;font-weight:500;white-space:nowrap;}
.pub-tab.on{color:#c9a96e;border-bottom-color:#c9a96e;}
.pub-sec{padding:24px 16px;max-width:480px;margin:0 auto;}
.pub-title{font-family:'Cormorant Garamond',serif;font-size:22px;color:#c9a96e;margin-bottom:14px;text-align:center;}
.pub-svc{background:#161616;border-radius:11px;border:1px solid #1e1e1e;padding:14px;margin-bottom:8px;}
.pub-wa-btn{display:inline-flex;align-items:center;gap:8px;background:#25d366;color:#fff;padding:11px 22px;border-radius:30px;font-weight:600;font-size:13px;cursor:pointer;border:none;font-family:'DM Sans',sans-serif;}
.pub-ig-btn{display:inline-flex;align-items:center;gap:8px;background:linear-gradient(135deg,#f09433,#e6683c,#dc2743,#cc2366,#bc1888);color:#fff;padding:11px 20px;border-radius:30px;font-weight:600;font-size:13px;cursor:pointer;border:none;font-family:'DM Sans',sans-serif;text-decoration:none;}
.pub-hor{display:flex;justify-content:space-between;padding:10px 13px;background:#161616;border-radius:9px;margin-bottom:6px;border:1px solid #1e1e1e;}
.pub-link{display:flex;align-items:center;gap:12px;background:#161616;border-radius:12px;padding:14px 16px;border:1px solid #1e1e1e;margin-bottom:8px;cursor:pointer;text-decoration:none;}
.pub-overlay{position:fixed;inset:0;background:rgba(0,0,0,.85);z-index:100;display:flex;align-items:flex-end;justify-content:center;backdrop-filter:blur(4px);}
.pub-modal{background:#111;border-radius:20px 20px 0 0;width:100%;max-width:480px;max-height:94vh;overflow-y:auto;border-top:1px solid #2a2a2a;}
.pub-mi{width:100%;padding:11px 13px;background:#1a1a1a;border:1px solid #2a2a2a;border-radius:9px;color:#fff;font-family:'DM Sans',sans-serif;font-size:13px;outline:none;}
.pub-mi:focus{border-color:#c9a96e;}
.pub-t-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:5px;}
.pub-t-btn{padding:9px 5px;border:1px solid #2a2a2a;border-radius:7px;background:#1a1a1a;cursor:pointer;font-family:'DM Sans',sans-serif;font-size:11px;color:#888;text-align:center;}
.pub-t-btn.on{border-color:#c9a96e;background:#c9a96e;color:#fff;font-weight:600;}
.pub-ag-btn{width:100%;background:linear-gradient(135deg,#c9a96e,#b8935a);color:#fff;border:none;border-radius:9px;padding:11px;font-family:'DM Sans',sans-serif;font-size:13px;font-weight:600;cursor:pointer;margin-top:8px;}
@media(max-width:768px){
  .sidebar{display:none;}
  .bot-nav{display:flex!important;position:fixed;bottom:0;left:0;right:0;background:#111;border-top:1px solid #1e1e1e;z-index:50;height:56px;}
  .bot-ni{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;cursor:pointer;color:#444;border:none;background:none;font-family:'DM Sans',sans-serif;padding:4px 2px;}
  .bot-ni.on{color:#c9a96e;}.bot-ni-i{font-size:16px;}.bot-ni-l{font-size:8px;font-weight:500;}
  .main{padding-bottom:56px;}.content{padding:12px;}.topbar{padding:10px 14px;}
  .topbar h2{font-size:17px;}.g2{grid-template-columns:1fr;}.g3,.g4{grid-template-columns:1fr 1fr;}
  .modal{border-radius:18px 18px 0 0;position:fixed;bottom:0;left:0;right:0;max-width:100%;max-height:93vh;}
  .overlay{align-items:flex-end;padding:0;}
  .modal-h{padding:16px 16px 0;}.modal-b{padding:0 16px;}.modal-f{padding:12px 16px 26px;}
  .notif{bottom:63px;right:10px;left:10px;}
}
`;


// SMALL COMPONENTS
function Av({n}){const i=(n||"?").split(" ").map(p=>p[0]).slice(0,2).join("").toUpperCase();return <div className="av">{i}</div>;}
function Tag({s}){const m={confirmado:"tag-ok",pendente:"tag-pend",cancelado:"tag-canc"};const l={confirmado:"Confirmado",pendente:"Pendente",cancelado:"Cancelado"};return <span className={`tag ${m[s]||""}`}>{l[s]||s}</span>;}
function Toast({msg,type,done}){useEffect(()=>{const t=setTimeout(done,4000);return()=>clearTimeout(t);},[]);return <div className={`notif ${type==="wa"?"notif-wa":type==="p"?"notif-p":""}`}>{msg}</div>;}

// LOGIN
function Login({onLogin,onPub}){
  const [pw,setPw]=useState("");const [err,setErr]=useState(false);
  const go=()=>{if(pw===SENHA){try{localStorage.setItem("er","1");sessionStorage.setItem("er","1");}catch(e){}onLogin();}else{setErr(true);setTimeout(()=>setErr(false),2000);}};
  return(<div style={{minHeight:"100vh",display:"flex",alignItems:"center",justifyContent:"center",background:"linear-gradient(135deg,#0d0d0d,#1a1208)",padding:20}}>
    <div style={{background:"#fff",borderRadius:20,padding:"40px 36px",width:"100%",maxWidth:360,textAlign:"center"}}>
      <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:52,fontWeight:300,color:"#c9a96e",lineHeight:1}}>ER</div>
      <div style={{fontSize:11,color:"#aaa",letterSpacing:2,textTransform:"uppercase",marginBottom:28}}>Evelyn Ramos · Estúdio Madame</div>
      <label style={{display:"block",fontSize:12,fontWeight:600,textTransform:"uppercase",color:"#aaa",marginBottom:5,textAlign:"left"}}>Senha</label>
      <input type="password" value={pw} onChange={e=>setPw(e.target.value)} onKeyDown={e=>e.key==="Enter"&&go()}
        style={{width:"100%",padding:"12px 14px",border:`1.5px solid ${err?"#ef4444":"#e0dbd0"}`,borderRadius:10,fontFamily:"'DM Sans',sans-serif",fontSize:15,outline:"none",marginBottom:14}}
        placeholder="••••••••" autoFocus/>
      <button onClick={go} style={{width:"100%",padding:13,background:"linear-gradient(135deg,#c9a96e,#b8935a)",color:"#fff",border:"none",borderRadius:10,fontFamily:"'DM Sans',sans-serif",fontSize:14,fontWeight:600,cursor:"pointer"}}>Entrar 🔐</button>
      {err&&<div style={{color:"#ef4444",fontSize:12,marginTop:8}}>❌ Senha incorreta</div>}
      <div style={{fontSize:10,color:"#ccc",marginTop:14}}>Área restrita — somente Evelyn</div>
      <button onClick={onPub} style={{marginTop:12,width:"100%",padding:10,border:"1px solid #e0dbd0",borderRadius:10,background:"#fff",fontFamily:"'DM Sans',sans-serif",fontSize:13,color:"#888",cursor:"pointer"}}>🌸 Ver página pública</button>
    </div>
  </div>);
}

// BOOKING MODAL
function BookingModal({onClose,onSave,dataInicio,apts}){
  const [step,setStep]=useState(1);
  const [f,setF]=useState({cliente:"",tel:"",svc:null,data:dataInicio||hj(),hora:"",bloq:90,tab:"svc",pacId:null,isPac:false});
  const up=(k,v)=>setF(p=>({...p,[k]:v}));
  const svcObj=SERVICOS.find(s=>s.nome===f.svc);
  const pac=PACOTES.find(p=>p.id===f.pacId);
  const horarios=hs(f.data);const ok=aberto(f.data);
  const bloqs=useMemo(()=>getBloqs(apts,f.data),[f.data,apts]);
  const canNext=(step===1&&f.cliente&&f.tel)||(step===2&&(f.tab==="svc"?f.svc:f.pacId))||(step===3&&f.data&&f.hora&&ok);
  const confirmar=()=>{
    if(f.isPac&&pac){
      const datas=sessoesPac(pac,f.data);const pid=uid();
      datas.forEach((d,i)=>onSave({id:uid(),cliente:f.cliente,tel:f.tel,servico:pac.servico,data:d,hora:f.hora,status:"pendente",valor:i===0?pac.preco:0,bloq:90,pago:false,pgto:null,total:i===0?pac.preco:0,troca:false,pacoteId:pid,sessao:i+1,pacNome:pac.nome,isPacote:true},true,i===0?{pac,datas}:null));
    }else{
      onSave({id:uid(),cliente:f.cliente,tel:f.tel,servico:f.svc,data:f.data,hora:f.hora,status:"pendente",valor:svcObj?.preco||0,bloq:svcObj?.bloq||90,pago:false,pgto:null,total:svcObj?.preco||0,troca:false,pacoteId:null,sessao:null,isPacote:false},false,null);
    }
  };
  return(<div className="overlay" onClick={e=>e.target===e.currentTarget&&onClose()}>
    <div className="modal">
      <div className="modal-h">
        <div className="modal-t">{["Dados da Cliente","Serviço / Pacote","Data & Horário"][step-1]}</div>
        <div className="modal-s">Passo {step} de 3</div>
        <div className="prog">{[1,2,3].map(n=><div key={n} className="prog-s" style={{background:n<=step?"#c9a96e":"#e0dbd0"}}/>)}</div>
      </div>
      <div className="modal-b">
        {step===1&&(<>
          <div className="fg"><label className="fl">Nome</label><input className="fi" value={f.cliente} onChange={e=>up("cliente",e.target.value)} placeholder="Ex: Ana Lima"/></div>
          <div className="fg"><label className="fl">WhatsApp</label><input className="fi" value={f.tel} onChange={e=>up("tel",e.target.value)} placeholder="16999999999"/></div>
        </>)}
        {step===2&&(<>
          <div style={{display:"flex",gap:6,marginBottom:12}}>
            <button onClick={()=>up("tab","svc")} className={`btn btn-sm ${f.tab==="svc"?"btn-gold":"btn-ghost"}`}>✂️ Serviços</button>
            <button onClick={()=>up("tab","pac")} className={`btn btn-sm ${f.tab==="pac"?"btn-purple":"btn-ghost"}`}>📦 Pacotes</button>
          </div>
          {f.tab==="svc"&&<div className="svc-grid">{SERVICOS.map(s=><button key={s.id} className={`svc-btn ${f.svc===s.nome?"on":""}`} onClick={()=>{up("svc",s.nome);up("bloq",s.bloq);up("isPac",false);}}>
            <div style={{fontSize:12,fontWeight:600,marginBottom:2}}>{s.emoji} {s.nome}</div>
            <div style={{fontSize:11,color:"#c9a96e",fontWeight:600}}>R${s.preco} · {s.dur}</div>
          </button>)}</div>}
          {f.tab==="pac"&&<div style={{display:"flex",flexDirection:"column",gap:8}}>{PACOTES.map(p=><button key={p.id} className={`svc-btn ${f.pacId===p.id?"on":""}`} style={{padding:12}} onClick={()=>{up("pacId",p.id);up("svc",p.servico);up("isPac",true);}}>
            <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:4}}><span style={{fontSize:16}}>{p.emoji}</span><span style={{fontWeight:600,fontSize:13}}>{p.nome}</span><span style={{marginLeft:"auto",color:"#c9a96e",fontFamily:"'Cormorant Garamond',serif",fontSize:18,fontWeight:600}}>R${p.preco}</span></div>
            <div style={{fontSize:11,color:"#888"}}>{p.sessoes} sessões · {p.semanal?"Mesmo dia toda semana":"Quinzenal"}</div>
          </button>)}</div>}
        </>)}
        {step===3&&(<>
          <div className="fg"><label className="fl">Data</label><input type="date" className="fi" value={f.data} min={hj()} onChange={e=>up("data",e.target.value)}/></div>
          {f.data&&!ok&&<div style={{background:"#fef2f2",border:"1px solid #fecaca",borderRadius:8,padding:"9px 12px",fontSize:12,color:"#dc2626",marginBottom:10}}>⚠️ Fechado. Atendimento: ter, qua, qui, sex, sáb.</div>}
          {f.data&&ok&&(<>
            <div className="fg"><label className="fl">Horário</label>
              <div className="t-grid">{horarios.map(h=>{const bl=bloqs.has(h);return<button key={h} className={`t-btn ${f.hora===h?"on":""} ${bl?"bloq":""}`} disabled={bl} onClick={()=>!bl&&up("hora",h)}>{h}</button>;})}</div>
            </div>
            {f.hora&&f.isPac&&pac&&<div style={{background:"#f5f3ff",borderRadius:9,padding:"10px 12px",fontSize:12,color:"#7c3aed"}}>
              📦 {pac.nome} · {sessoesPac(pac,f.data).map((d,i)=>`S${i+1}: ${SEMANA[dow(d)]} ${fD(d)}`).join(" · ")}
            </div>}
          </>)}
        </>)}
      </div>
      <div className="modal-f">
        {step>1&&<button className="btn btn-ghost btn-sm" onClick={()=>setStep(s=>s-1)}>← Voltar</button>}
        <button className="btn btn-ghost btn-sm" onClick={onClose}>Cancelar</button>
        {step<3?<button className="btn btn-gold" disabled={!canNext} onClick={()=>setStep(s=>s+1)}>Próximo →</button>
         :<button className="btn btn-gold" disabled={!canNext} onClick={confirmar}>✓ Confirmar</button>}
      </div>
    </div>
  </div>);
}

// TROCA MODAL
function TrocaModal({onClose,onSave,apts}){
  const [f,setF]=useState({cliente:"",svc:"Coloração",data:hj(),hora:"",obs:""});
  const up=(k,v)=>setF(p=>({...p,[k]:v}));
  const horarios=hs(f.data);const ok=aberto(f.data);
  const bloqs=useMemo(()=>getBloqs(apts,f.data),[f.data,apts]);
  return(<div className="overlay" onClick={e=>e.target===e.currentTarget&&onClose()}>
    <div className="modal">
      <div className="modal-h">
        <div style={{marginBottom:6}}><span className="tag tag-troca">🔄 TROCA DE SERVIÇO</span></div>
        <div className="modal-t">Agendar Troca</div>
        <div className="modal-s" style={{color:"#16a34a"}}>Não contabiliza no financeiro</div>
      </div>
      <div className="modal-b">
        <div style={{background:"#f0fdf4",borderRadius:9,padding:"10px 13px",marginBottom:14,fontSize:12,color:"#16a34a",border:"1px solid #86efac"}}>✅ Troca de serviço — não entra no faturamento mensal.</div>
        <div style={{marginBottom:14}}>
          <div style={{fontSize:12,fontWeight:700,color:"#555",marginBottom:8}}>Parceiras cadastradas:</div>
          {PARCEIRAS.map(p=><button key={p.id} onClick={()=>up("cliente",p.nome)} style={{display:"block",width:"100%",padding:"10px 14px",border:`2px solid ${f.cliente===p.nome?"#16a34a":"#e0dbd0"}`,borderRadius:9,background:f.cliente===p.nome?"#f0fdf4":"#fff",cursor:"pointer",textAlign:"left",marginBottom:6,fontFamily:"'DM Sans',sans-serif"}}>
            <div style={{fontWeight:600,fontSize:13}}>{p.nome}</div>
            <div style={{fontSize:11,color:"#888"}}>{p.servico}</div>
          </button>)}
        </div>
        <div className="fg"><label className="fl">Ou outro nome</label><input className="fi" value={f.cliente} onChange={e=>up("cliente",e.target.value)} placeholder="Ex: Fernanda — Manicure"/></div>
        <div className="fg"><label className="fl">Serviço que você vai fazer</label>
          <select className="fi" value={f.svc} onChange={e=>up("svc",e.target.value)}>{SERVICOS.map(s=><option key={s.id}>{s.nome}</option>)}</select>
        </div>
        <div className="fg"><label className="fl">Data</label><input type="date" className="fi" value={f.data} min={hj()} onChange={e=>up("data",e.target.value)}/></div>
        {f.data&&ok&&<div className="fg"><label className="fl">Horário</label>
          <div className="t-grid">{horarios.map(h=>{const bl=bloqs.has(h);return<button key={h} className={`t-btn ${f.hora===h?"on":""} ${bl?"bloq":""}`} disabled={bl} onClick={()=>!bl&&up("hora",h)}>{h}</button>;})}</div>
        </div>}
        <div className="fg"><label className="fl">Observação</label><input className="fi" value={f.obs} onChange={e=>up("obs",e.target.value)} placeholder="Ex: Troca: massagem por corte"/></div>
      </div>
      <div className="modal-f">
        <button className="btn btn-ghost btn-sm" onClick={onClose}>Cancelar</button>
        <button className="btn btn-green" disabled={!f.cliente||!f.hora||!ok} onClick={()=>onSave({id:uid(),cliente:f.cliente,tel:"",servico:f.svc,data:f.data,hora:f.hora,status:"confirmado",valor:0,bloq:90,pago:false,pgto:null,total:0,troca:true,obs:f.obs,pacoteId:null,sessao:null,isPacote:false})}>✓ Confirmar Troca</button>
      </div>
    </div>
  </div>);
}

// FICHA MODAL
function FichaModal({cliente,fichas,onSave,onClose}){
  const [x,setX]=useState("");const [num,setNum]=useState("");const [g,setG]=useState(30);
  const [ox,setOx]=useState(20);const [obs,setObs]=useState("");const [data,setData]=useState(hj());
  const [svc,setSvc]=useState("Coloração");
  const minhas=fichas.filter(f=>f.clientName===cliente.nome).sort((a,b)=>b.data.localeCompare(a.data));
  const salvar=()=>{if(!num.trim())return;onSave({id:uid(),clientName:cliente.nome,svc,x:x||"X",num:num.trim(),g:Number(g),ox:Number(ox),obs:obs.trim(),data});setNum("");setX("");setObs("");setG(30);setOx(20);};
  return(<div className="overlay" onClick={e=>e.target===e.currentTarget&&onClose()}>
    <div className="modal" style={{maxWidth:520}}>
      <div className="modal-h">
        <div className="modal-t">💜 Ficha Técnica</div>
        <div className="modal-s">{cliente.nome} — Dicollore</div>
      </div>
      <div className="modal-b">
        <div style={{background:"#f5f3ff",borderRadius:10,padding:"14px",marginBottom:16,border:"1px solid #ddd6fe"}}>
          <div style={{fontSize:12,fontWeight:700,color:"#7c3aed",marginBottom:12}}>+ Nova aplicação</div>
          <div className="fg"><label className="fl">Serviço</label>
            <select className="fi" value={svc} onChange={e=>setSvc(e.target.value)}>{FICHA_SVCS.map(s=><option key={s}>{s}</option>)}</select>
          </div>
          <div style={{display:"flex",gap:8,marginBottom:10}}>
            <div style={{flex:"0 0 65px"}}><label className="fl">X</label><input className="fi" value={x} onChange={e=>setX(e.target.value)} placeholder="7"/></div>
            <div style={{flex:1}}><label className="fl">Tonalidade</label><input className="fi" value={num} onChange={e=>setNum(e.target.value)} placeholder="7.7 ou 8.0"/></div>
            <div style={{flex:"0 0 70px"}}><label className="fl">Gramas</label><input type="number" className="fi" value={g} onChange={e=>setG(e.target.value)} min={10} max={200} step={5}/></div>
            <div style={{flex:"0 0 60px"}}><label className="fl">Ox</label><select className="fi" value={ox} onChange={e=>setOx(e.target.value)}><option>10</option><option>20</option><option>30</option><option>40</option></select></div>
          </div>
          <div style={{display:"flex",gap:8,marginBottom:10}}>
            <div style={{flex:"0 0 130px"}}><label className="fl">Data</label><input type="date" className="fi" value={data} onChange={e=>setData(e.target.value)}/></div>
            <div style={{flex:1}}><label className="fl">Observação</label><input className="fi" value={obs} onChange={e=>setObs(e.target.value)} placeholder="Pós-descoloração, raiz..."/></div>
          </div>
          {num&&<div style={{display:"flex",alignItems:"center",gap:10,background:"#fff",borderRadius:8,padding:"10px 12px",border:"1px solid #e0dbd0"}}>
            <div style={{width:28,height:28,borderRadius:"50%",background:"#b89060",border:"2px solid #ddd6fe",flexShrink:0}}/>
            <div style={{flex:1}}><div style={{fontWeight:700,fontSize:13}}>Dicollore {x||"X"}.{num}</div><div style={{fontSize:11,color:"#888"}}>{g}g · Ox {ox}</div></div>
            <button className="btn btn-purple btn-xs" onClick={salvar}>💾 Salvar</button>
          </div>}
        </div>
        <div style={{fontSize:13,fontWeight:700,color:"#555",marginBottom:10}}>Histórico ({minhas.length})</div>
        {minhas.length===0?<div className="empty" style={{padding:20}}><div className="empty-i">💜</div><p>Nenhuma ficha ainda</p></div>
         :minhas.map(f=><div key={f.id} style={{background:"#fff",borderRadius:10,border:"1px solid #ebe8e0",padding:14,marginBottom:8}}>
            <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:f.obs?8:0}}>
              <div style={{width:22,height:22,borderRadius:"50%",background:"#b89060",border:"2px solid #ddd6fe",flexShrink:0}}/>
              <div style={{flex:1}}><div style={{fontWeight:700,fontSize:13,color:"#7c3aed"}}>Dicollore {f.x}.{f.num}</div><div style={{fontSize:11,color:"#888"}}>{f.svc} · {f.g}g · Ox {f.ox}</div></div>
              <div style={{fontSize:13,fontWeight:600,color:"#555"}}>{fD(f.data)}</div>
            </div>
            {f.obs&&<div style={{fontSize:12,color:"#888",background:"#f7f5f0",borderRadius:7,padding:"6px 10px"}}>📝 {f.obs}</div>}
          </div>)
        }
      </div>
      <div className="modal-f"><button className="btn btn-ghost" onClick={onClose}>Fechar</button></div>
    </div>
  </div>);
}

// FINALIZAR MODAL
function FinalizarModal({apt,onClose,onSave,stock}){
  const [pgto,setPgto]=useState(null);const [extras,setExtras]=useState([]);
  const [busca,setBusca]=useState("");const [descM,setDescM]=useState(null);
  const addE=p=>setExtras(prev=>{const ex=prev.find(x=>x.id===p.id);return ex?prev.map(x=>x.id===p.id?{...x,qty:x.qty+1}:x):[...prev,{...p,qty:1,preco:Math.round((p.custo||50)*2.2)}];});
  const remE=id=>setExtras(prev=>prev.filter(x=>x.id!==id));
  const temDesc=pgto==="pix"||pgto==="dinheiro";
  const pct=descM!==null?descM:(temDesc?5:0);
  const extV=extras.reduce((s,x)=>s+x.preco*x.qty,0);
  const sub=(apt.valor||0)+extV;
  const desc=Math.round(sub*pct/100);
  const total=sub-desc;
  const filtrados=stock.filter(p=>p.nome.toLowerCase().includes(busca.toLowerCase()));
  return(<div className="overlay" onClick={e=>e.target===e.currentTarget&&onClose()}>
    <div className="modal" style={{maxWidth:480}}>
      <div className="modal-h">
        <div className="modal-t">✓ Finalizar Atendimento</div>
        <div className="modal-s">{apt.cliente} · {apt.servico}</div>
      </div>
      <div className="modal-b">
        <div style={{fontSize:12,fontWeight:700,color:"#7c3aed",marginBottom:8,textTransform:"uppercase",letterSpacing:.5}}>🛍 Produtos extras</div>
        <input className="fi" placeholder="🔍 Buscar produto do estoque..." value={busca} onChange={e=>setBusca(e.target.value)} style={{marginBottom:8}}/>
        {busca&&<div style={{maxHeight:150,overflowY:"auto",border:"1px solid #e0dbd0",borderRadius:8,marginBottom:10}}>
          {filtrados.slice(0,10).map(p=><div key={p.id} style={{display:"flex",alignItems:"center",gap:10,padding:"9px 12px",borderBottom:"1px solid #f5f3ee",cursor:"pointer"}} onClick={()=>{addE(p);setBusca("");}}>
            <div style={{flex:1}}><div style={{fontSize:12,fontWeight:500}}>{p.nome}</div><div style={{fontSize:11,color:"#aaa"}}>{p.marca}</div></div>
            <div style={{color:"#c9a96e",fontFamily:"'Cormorant Garamond',serif",fontSize:16,fontWeight:600}}>R${Math.round((p.custo||50)*2.2)}</div>
            <button className="btn btn-gold btn-xs">+</button>
          </div>)}
        </div>}
        {extras.length>0&&<div style={{background:"#f5f3ff",borderRadius:9,padding:"10px 12px",marginBottom:12}}>
          {extras.map(e=><div key={e.id} style={{display:"flex",alignItems:"center",gap:10,marginBottom:6}}>
            <div style={{flex:1}}><div style={{fontSize:12,fontWeight:500}}>{e.nome}</div><div style={{fontSize:11,color:"#7c3aed"}}>x{e.qty} · R${e.preco*e.qty}</div></div>
            <button style={{width:24,height:24,borderRadius:"50%",border:"1px solid #e0dbd0",background:"#fff",cursor:"pointer",fontSize:13}} onClick={()=>addE(e)}>+</button>
            <button style={{width:24,height:24,borderRadius:"50%",border:"1px solid #fecaca",background:"#fef2f2",cursor:"pointer",fontSize:11,color:"#ef4444"}} onClick={()=>remE(e.id)}>✕</button>
          </div>)}
        </div>}
        <div style={{fontSize:12,fontWeight:700,marginBottom:8,textTransform:"uppercase",letterSpacing:.5}}>💳 Pagamento</div>
        <div className="pgto-grid">
          {[{id:"pix",icon:"📱",l:"PIX",d:"5% off"},{id:"dinheiro",icon:"💵",l:"Dinheiro",d:"5% off"},{id:"debito",icon:"💳",l:"Débito",d:"sem taxa"},{id:"credito",icon:"💳",l:"Crédito",d:"sem desc."}].map(p=><button key={p.id} className={`pgto-btn ${pgto===p.id?"on-"+p.id:""}`} onClick={()=>setPgto(p.id)}>
            <div style={{fontSize:20,marginBottom:4}}>{p.icon}</div>
            <div style={{fontWeight:700,fontSize:13}}>{p.l}</div>
            <div style={{fontSize:11,color:pgto===p.id&&temDesc?"#16a34a":"#aaa"}}>{p.d}</div>
          </button>)}
        </div>
        {pgto&&<div style={{display:"flex",alignItems:"center",gap:10,background:"#f7f5f0",borderRadius:8,padding:"9px 12px",marginBottom:12}}>
          <span style={{fontSize:12,color:"#888",flex:1}}>Desconto:</span>
          <input type="number" min={0} max={100} value={descM!==null?descM:(temDesc?5:0)} onChange={e=>setDescM(Number(e.target.value))} style={{width:55,padding:"5px 8px",border:"1px solid #e0dbd0",borderRadius:6,fontFamily:"'DM Sans',sans-serif",fontSize:12,textAlign:"center"}}/>
          <span style={{fontSize:12,color:"#888"}}>%</span>
        </div>}
        <div style={{background:"#1a1a1a",borderRadius:12,padding:16,color:"#fff"}}>
          <div style={{fontSize:11,color:"#888",textTransform:"uppercase",letterSpacing:.7,marginBottom:10}}>Resumo</div>
          <div style={{display:"flex",justifyContent:"space-between",fontSize:13,marginBottom:6}}><span style={{color:"#bbb"}}>Serviço</span><span>R${apt.valor}</span></div>
          {extras.map(e=><div key={e.id} style={{display:"flex",justifyContent:"space-between",fontSize:13,marginBottom:6}}><span style={{color:"#bbb"}}>{e.nome} x{e.qty}</span><span style={{color:"#c9a96e"}}>+R${e.preco*e.qty}</span></div>)}
          <div style={{borderTop:"1px solid #2a2a2a",marginTop:8,paddingTop:8,display:"flex",justifyContent:"space-between",fontSize:13,marginBottom:desc>0?6:0}}><span style={{color:"#bbb"}}>Subtotal</span><span>R${sub}</span></div>
          {desc>0&&<div style={{display:"flex",justifyContent:"space-between",fontSize:13,marginBottom:6}}><span style={{color:"#22c55e"}}>Desconto {pct}%</span><span style={{color:"#22c55e"}}>-R${desc}</span></div>}
          <div style={{borderTop:"1px solid #2a2a2a",marginTop:8,paddingTop:10,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
            <span style={{fontSize:14,fontWeight:700}}>Total</span>
            <span style={{fontFamily:"'Cormorant Garamond',serif",fontSize:28,color:"#c9a96e",fontWeight:600}}>R${total}</span>
          </div>
        </div>
      </div>
      <div className="modal-f">
        <button className="btn btn-ghost btn-sm" onClick={onClose}>Cancelar</button>
        <button className="btn btn-gold" style={{flex:1,justifyContent:"center"}} disabled={!pgto} onClick={()=>onSave({pgto,extras,desc,pct,total})}>✓ Confirmar R${total}</button>
      </div>
    </div>
  </div>);
}


// VIEWS PRINCIPAIS
function Dashboard({apts,clientes,onNew,onWA,notify}){
  const t=hj(),now=new Date(),mes=now.getMonth(),ano=now.getFullYear();
  const hojeApts=apts.filter(a=>a.data===t).sort((a,b)=>a.hora>b.hora?1:-1);
  const pend=apts.filter(a=>a.status==="pendente");
  const recMes=apts.filter(a=>{const[y,m]=(a.data||"").split("-");return Number(y)===ano&&Number(m)-1===mes&&a.status==="confirmado"&&!a.troca;}).reduce((s,a)=>s+(a.total||0),0);
  const pct=Math.min(100,Math.round((recMes/META)*100));
  const anivs=clientes.filter(c=>c.aniv&&c.aniv.slice(5)===hdmm());
  return(<>
    {anivs.length>0&&<div style={{background:"linear-gradient(135deg,#fdf2f8,#fce7f3)",border:"1px solid #f9a8d4",borderRadius:12,padding:"12px 16px",marginBottom:14,display:"flex",alignItems:"center",gap:10}}>
      <span style={{fontSize:22}}>🎂</span><div style={{flex:1}}><div style={{fontSize:13,fontWeight:700,color:"#be185d"}}>Aniversário hoje!</div><div style={{fontSize:11,color:"#9d174d"}}>{anivs.map(c=>c.nome).join(", ")}</div></div>
      {anivs.slice(0,2).map(c=><button key={c.id} className="btn btn-xs" style={{background:"#ec4899",color:"#fff"}} onClick={()=>{openWA(c.tel,msgs.aniv(c.nome.split(" ")[0]));notify("🎂 Parabéns enviado!","wa");}}>🎂 WA</button>)}
    </div>}
    <div style={{background:"linear-gradient(135deg,#1a1a1a,#2a2010)",borderRadius:13,padding:"18px 22px",marginBottom:16,color:"#fff",position:"relative",overflow:"hidden"}}>
      <div style={{position:"absolute",right:16,top:"50%",transform:"translateY(-50%)",fontFamily:"'Cormorant Garamond',serif",fontSize:70,fontWeight:300,color:"rgba(201,169,110,.08)"}}>ER</div>
      <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:24,fontWeight:300,color:"#c9a96e"}}>Evelyn Ramos</div>
      <div style={{fontSize:12,color:"#555",letterSpacing:1.5,textTransform:"uppercase",marginTop:2,marginBottom:14}}>Cabeleireira · Estúdio Madame 🔐</div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:6}}>
        <span style={{fontSize:11,color:"#888"}}>Meta: R${META.toLocaleString("pt-BR")}</span>
        <span style={{fontFamily:"'Cormorant Garamond',serif",fontSize:20,color:pct>=100?"#4ade80":pct>=70?"#fbbf24":"#f87171",fontWeight:600}}>{pct}%</span>
      </div>
      <div className="meta-bar"><div className="meta-fill" style={{width:`${pct}%`,background:pct>=70?"linear-gradient(90deg,#22c55e,#86efac)":pct>=40?"linear-gradient(90deg,#f59e0b,#fde68a)":"linear-gradient(90deg,#ef4444,#fca5a5)"}}/></div>
      <div style={{fontSize:11,color:"#555",marginTop:4}}>R${recMes.toLocaleString("pt-BR")} · {MESES[mes]}</div>
    </div>
    <div className="g4" style={{marginBottom:14}}>
      <div className="stat"><div className="stat-l">Hoje</div><div className="stat-v">{hojeApts.length}</div><div className="stat-s">agend.</div></div>
      <div className="stat"><div className="stat-l">Pendentes</div><div className="stat-v red">{pend.length}</div></div>
      <div className="stat"><div className="stat-l">Faturado</div><div className="stat-v gold">R${recMes}</div><div className="stat-s">{MESES[mes]}</div></div>
      <div className="stat"><div className="stat-l">Clientes</div><div className="stat-v purple">{clientes.length}</div></div>
    </div>
    <div className="g2">
      <div className="card"><div className="card-h"><span className="card-t">📅 Hoje</span><button className="btn btn-gold btn-xs" onClick={onNew}>+ Novo</button></div>
        <div className="card-b" style={{padding:"0 18px"}}>
          {hojeApts.length===0?<div className="empty"><div className="empty-i">🌿</div><p>Sem agendamentos hoje</p></div>
           :hojeApts.map(a=><div key={a.id} className="row"><Av n={a.cliente}/><div style={{flex:1}}><div style={{fontWeight:600,fontSize:13}}>{a.cliente}</div><div style={{fontSize:12,color:"#aaa"}}>{a.servico}{a.troca?" 🔄":""}{a.isPacote?` · S${a.sessao}`:""}</div></div><div style={{textAlign:"right"}}><div style={{fontWeight:700,fontSize:14}}>{a.hora}</div><Tag s={a.status}/></div></div>)}
        </div>
      </div>
      <div className="card"><div className="card-h"><span className="card-t">⏳ Pendentes</span></div>
        <div className="card-b" style={{padding:"0 18px"}}>
          {pend.length===0?<div className="empty"><div className="empty-i">✅</div><p>Todos confirmados!</p></div>
           :pend.slice(0,5).map(a=><div key={a.id} className="row"><Av n={a.cliente}/><div style={{flex:1}}><div style={{fontWeight:600,fontSize:13}}>{a.cliente}</div><div style={{fontSize:12,color:"#aaa"}}>{a.servico} · {fD(a.data)}</div></div><button className="btn btn-wa btn-xs" onClick={()=>onWA(a)}>📱</button></div>)}
        </div>
      </div>
    </div>
  </>);
}

function AgendaView({apts,onNew}){
  const now=new Date();
  const [yr,setYr]=useState(now.getFullYear());const [mo,setMo]=useState(now.getMonth());const [sel,setSel]=useState(hj());
  const TODAY=hj();
  const nd=nDias(yr,mo);const pd=pDia(yr,mo);
  const ds=d=>`${yr}-${s2(mo+1)}-${s2(d)}`;
  const aptDatas=useMemo(()=>new Set(apts.filter(a=>a.data).map(a=>a.data)),[apts]);
  const selApts=useMemo(()=>apts.filter(a=>a.data===sel).sort((a,b)=>a.hora>b.hora?1:-1),[apts,sel]);
  return(<div className="g2">
    <div className="card"><div className="card-b">
      <div className="cal-nav"><button className="cal-arr" onClick={()=>mo===0?(setMo(11),setYr(y=>y-1)):setMo(m=>m-1)}>‹</button><span className="cal-month">{MESES[mo]} {yr}</span><button className="cal-arr" onClick={()=>mo===11?(setMo(0),setYr(y=>y+1)):setMo(m=>m+1)}>›</button></div>
      <div className="cal-grid">
        {SEMANA.map(d=><div key={d} className="cal-wd">{d}</div>)}
        {Array(pd).fill(null).map((_,i)=><div key={"e"+i} className="cal-d ce"/>)}
        {Array(nd).fill(null).map((_,i)=>{const d=i+1,s=ds(d),f=!aberto(s);return<div key={d} className={"cal-d"+(s===TODAY?" ct":"")+(s===sel&&s!==TODAY?" cs":"")+(aptDatas.has(s)?" ch":"")+(f?" cx":"")} onClick={()=>!f&&setSel(s)}>{d}</div>;})}
      </div>
    </div></div>
    <div className="card">
      <div className="card-h"><span className="card-t">{fD(sel)}</span>{aberto(sel)&&<button className="btn btn-gold btn-xs" onClick={()=>onNew(sel)}>+ Agendar</button>}</div>
      <div className="card-b" style={{padding:"0 18px"}}>
        {!aberto(sel)?<div className="empty"><div className="empty-i">🚫</div><p>Dia fechado</p></div>
         :selApts.length===0?<div className="empty"><div className="empty-i">📆</div><p>Nenhum agendamento</p></div>
         :selApts.map(a=><div key={a.id} className="row">
            <Av n={a.cliente}/>
            <div style={{flex:1}}><div style={{fontWeight:600,fontSize:13}}>{a.cliente}{a.troca&&<span className="tag tag-troca" style={{marginLeft:6,fontSize:10}}>🔄</span>}{a.isPacote&&<span className="tag tag-pac" style={{marginLeft:6,fontSize:10}}>S{a.sessao}</span>}</div><div style={{fontSize:12,color:"#aaa"}}>{a.servico} · R${a.valor}</div></div>
            <div style={{textAlign:"right"}}><div style={{fontWeight:700,fontSize:14}}>{a.hora}</div><Tag s={a.status}/></div>
          </div>)}
      </div>
    </div>
  </div>);
}

function AtendimentoView({apts,setApts,stock,setStock,notify}){
  const t=hj();
  const hojeApts=apts.filter(a=>a.data===t&&a.status!=="cancelado").sort((a,b)=>a.hora>b.hora?1:-1);
  const [ativo,setAtivo]=useState(null);const [finalizando,setFinalizando]=useState(null);
  const iniciar=apt=>{setAtivo(apt.id);setApts(p=>p.map(a=>a.id===apt.id?{...a,status:"confirmado"}:a));notify("▶ Atendimento iniciado!","wa");};
  const finalizar=(apt,dados)=>{
    setApts(p=>p.map(a=>a.id===apt.id?{...a,pago:true,pgto:dados.pgto,total:dados.total,desconto:dados.desc,extras:dados.extras,status:"confirmado"}:a));
    // Baixa automática do estoque
    if(dados.baixarEstoque){
      setStock(p=>{
        const novo=[...p];
        dados.baixarEstoque.forEach(({id,qtd})=>{
          const idx=novo.findIndex(s=>s.id===id);
          if(idx>=0) novo[idx]={...novo[idx],qtd:Math.max(0,novo[idx].qtd-qtd)};
        });
        return novo;
      });
    }
    setAtivo(null);setFinalizando(null);
    notify(`✓ Finalizado! R$${dados.total} via ${dados.pgto.toUpperCase()}`,"wa");
  };
  return(<>
    <div style={{background:"linear-gradient(135deg,#f0fdf4,#ecfdf5)",borderRadius:12,padding:"14px 18px",marginBottom:16,border:"1px solid #bbf7d0"}}>
      <div style={{fontSize:13,fontWeight:700,color:"#16a34a",marginBottom:4}}>⏱ Atendimentos de Hoje</div>
      <div style={{fontSize:11,color:"#666"}}>Inicie o atendimento, adicione produtos extras e finalize com pagamento.</div>
    </div>
    {hojeApts.length===0&&<div className="empty"><div className="empty-i">🌿</div><p>Nenhum atendimento hoje</p></div>}
    {hojeApts.map(apt=>{const isAtivo=ativo===apt.id;return(
      <div key={apt.id} style={{background:"#fff",borderRadius:12,border:`1.5px solid ${apt.pago?"#c9a96e":isAtivo?"#22c55e":"#ebe8e0"}`,padding:"14px 18px",marginBottom:10}}>
        <div style={{display:"flex",alignItems:"center",gap:12}}>
          <div style={{width:40,height:40,borderRadius:"50%",background:apt.pago?"#fffdf7":isAtivo?"#dcfce7":"linear-gradient(135deg,#f0e8d5,#e8d9be)",display:"flex",alignItems:"center",justifyContent:"center",fontWeight:700,fontSize:13,color:apt.pago?"#c9a96e":isAtivo?"#16a34a":"#8a6f3e",flexShrink:0}}>
            {apt.pago?"✓":isAtivo?"▶":apt.cliente.split(" ").map(p=>p[0]).slice(0,2).join("").toUpperCase()}
          </div>
          <div style={{flex:1}}>
            <div style={{fontWeight:600,fontSize:13}}>{apt.cliente}</div>
            <div style={{fontSize:12,color:"#aaa"}}>{apt.servico} · {apt.hora}</div>
            {apt.pago&&<div style={{fontSize:11,color:"#c9a96e",fontWeight:600,marginTop:2}}>✓ Pago R${apt.total} via {apt.pgto?.toUpperCase()}</div>}
          </div>
          <div style={{display:"flex",flexDirection:"column",gap:6,alignItems:"flex-end"}}>
            <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:18,color:"#c9a96e",fontWeight:600}}>R${apt.valor}</div>
            {!apt.pago&&!isAtivo&&<button className="btn btn-gold btn-xs" onClick={()=>iniciar(apt)}>▶ Iniciar</button>}
            {isAtivo&&<button className="btn btn-xs btn-green" onClick={()=>setFinalizando(apt)}>✓ Finalizar</button>}
            {apt.pago&&<span style={{fontSize:10,background:"#f0fdf4",color:"#16a34a",padding:"2px 8px",borderRadius:8,fontWeight:700}}>✓ Pago</span>}
          </div>
        </div>
      </div>
    );})}
    {finalizando&&<FinalizarModal apt={finalizando} stock={stock} onClose={()=>setFinalizando(null)} onSave={dados=>finalizar(finalizando,dados)}/>}
  </>);
}

function AgendamentosView({apts,onSt,onNew,onWA,onFicha}){
  const [f,setF]=useState("todos");
  const lista=f==="todos"?apts:apts.filter(a=>a.status===f);
  return(<div className="card"><div className="card-h">
    <div style={{display:"flex",gap:4,flexWrap:"wrap"}}>
      {["todos","confirmado","pendente","cancelado"].map(x=><button key={x} className={`btn btn-xs ${f===x?"btn-gold":"btn-ghost"}`} onClick={()=>setF(x)}>{x.charAt(0).toUpperCase()+x.slice(1)}</button>)}
    </div>
    <button className="btn btn-gold btn-xs" onClick={onNew}>+ Novo</button>
  </div>
  <div className="card-b" style={{padding:0}}>
    {lista.length===0?<div className="empty"><div className="empty-i">🗓</div><p>Nenhum</p></div>
     :<div style={{overflowX:"auto"}}><table className="tbl"><thead><tr><th>Cliente</th><th>Serviço</th><th>Data</th><th>Hora</th><th>Valor</th><th>Status</th><th>Ações</th></tr></thead>
       <tbody>{lista.sort((a,b)=>a.data>b.data?1:-1).map(a=><tr key={a.id}>
         <td style={{fontWeight:500}}>{a.cliente}{a.troca&&<span className="tag tag-troca" style={{marginLeft:5,fontSize:10}}>🔄</span>}{a.isPacote&&<span className="tag tag-pac" style={{marginLeft:5,fontSize:10}}>S{a.sessao}</span>}</td>
         <td style={{fontSize:12}}>{a.servico}</td><td style={{color:"#888"}}>{fD(a.data)}</td><td style={{fontWeight:600}}>{a.hora}</td>
         <td style={{color:"#c9a96e",fontWeight:600}}>{a.total>0?`R$${a.total}`:"Troca"}</td>
         <td><Tag s={a.status}/></td>
         <td><div style={{display:"flex",gap:4}}>
           <button className="btn btn-wa btn-xs" onClick={()=>onWA(a)}>📱</button>
           {a.status!=="confirmado"&&<button className="btn btn-xs" style={{background:"#f0fdf4",color:"#16a34a",border:"1px solid #bbf7d0"}} onClick={()=>onSt(a.id,"confirmado")}>✓</button>}
           {a.status!=="cancelado"&&<button className="btn btn-red btn-xs" onClick={()=>onSt(a.id,"cancelado")}>✕</button>}
           {FICHA_SVCS.includes(a.servico)&&<button className="btn btn-xs" style={{background:"#f5f3ff",color:"#7c3aed",border:"1px solid #ddd6fe"}} onClick={()=>onFicha({nome:a.cliente,tel:a.tel||""})}>💜</button>}
         </div></td>
       </tr>)}</tbody></table></div>}
  </div></div>);
}

function ClientesView({apts,clientes,setClientes,fichas,notify,onFicha}){
  const [busca,setBusca]=useState("");const [tab,setTab]=useState("todos");
  const [showForm,setShowForm]=useState(false);const [editId,setEditId]=useState(null);
  const [fm,setFm]=useState({nome:"",tel:"",aniv:"",obs:""});
  const [selLimpeza,setSelLimpeza]=useState(new Set());
  const [confirmLimpeza,setConfirmLimpeza]=useState(false);
  const upF=(k,v)=>setFm(p=>({...p,[k]:v}));
  const anivMM=hdmm();const tresAtras=m3ago();
  const enriched=useMemo(()=>clientes.map(c=>{
    const ca=apts.filter(a=>a.cliente===c.nome&&a.status==="confirmado"&&!a.troca);
    const last=ca.sort((a,b)=>b.data.localeCompare(a.data))[0];
    const total=ca.reduce((s,a)=>s+(a.total||0),0);
    const dias=last?Math.floor((new Date()-new Date(last.data))/(1000*60*60*24)):null;
    const isAniv=c.aniv?c.aniv.slice(5)===anivMM:false;
    const reat=dias!==null&&dias>=90;
    const lastSvc=last?SERVICOS.find(s=>s.nome===last.servico):null;
    const lastFicha=fichas.filter(f=>f.clientName===c.nome).sort((a,b)=>b.data.localeCompare(a.data))[0];
    const anoAtras=m1ano();
    const inativa=!last||(last.data<anoAtras);     // nunca veio OU mais de 1 ano
    const nuncaVeio=ca.length===0;
    return{...c,ca,last,total,dias,isAniv,reat,lastSvc,lastFicha,visitas:ca.length,inativa,nuncaVeio};
  }),[clientes,apts,anivMM,fichas]);
  const anivs=enriched.filter(c=>c.isAniv);const reats=enriched.filter(c=>c.reat);
  const inativas=enriched.filter(c=>c.inativa);
  const filtrados=enriched.filter(c=>{
    const m=c.nome.toLowerCase().includes(busca.toLowerCase());
    if(tab==="aniv")return m&&c.isAniv;
    if(tab==="reat")return m&&c.reat;
    if(tab==="limpeza")return m&&c.inativa;
    return m;
  });
  const salvar=()=>{if(editId)setClientes(p=>p.map(c=>c.id===editId?{...c,...fm}:c));else setClientes(p=>[...p,{id:uid(),...fm,criado:hj()}]);setShowForm(false);setEditId(null);};
  return(<>
    {anivs.length>0&&<div style={{background:"linear-gradient(135deg,#fdf2f8,#fce7f3)",border:"1px solid #f9a8d4",borderRadius:12,padding:"12px 16px",marginBottom:12,display:"flex",alignItems:"center",gap:10}}>
      <span style={{fontSize:22}}>🎂</span><div style={{flex:1}}><div style={{fontSize:13,fontWeight:700,color:"#be185d"}}>Aniversário hoje!</div><div style={{fontSize:11,color:"#9d174d"}}>{anivs.map(c=>c.nome).join(", ")}</div></div>
      {anivs.slice(0,2).map(c=><button key={c.id} className="btn btn-xs" style={{background:"#ec4899",color:"#fff"}} onClick={()=>{openWA(c.tel,msgs.aniv(c.nome.split(" ")[0]));notify("🎂 WA enviado!","wa");}}>🎂</button>)}
    </div>}
    {reats.length>0&&<div style={{background:"#fffbeb",border:"1px solid #fde68a",borderRadius:12,padding:"11px 15px",marginBottom:12,display:"flex",alignItems:"center",gap:10}}>
      <span style={{fontSize:18}}>💌</span><div><div style={{fontSize:12,fontWeight:600,color:"#d97706"}}>{reats.length} cliente{reats.length>1?"s":""} há 3+ meses sem visitar</div><div style={{fontSize:11,color:"#b45309"}}>{reats.slice(0,4).map(c=>c.nome).join(", ")}</div></div>
    </div>}
    <div style={{display:"flex",gap:8,marginBottom:12,flexWrap:"wrap",alignItems:"center"}}>
      <input className="fi" style={{flex:1,minWidth:140}} placeholder="🔍 Buscar..." value={busca} onChange={e=>setBusca(e.target.value)}/>
      <div className="ctabs" style={{margin:0}}>
        {[{id:"todos",l:`Todas (${enriched.length})`},{id:"aniv",l:`🎂 (${anivs.length})`},{id:"reat",l:`💌 (${reats.length})`},{id:"limpeza",l:`🗑 Inativas (${inativas.length})`}].map(t=><button key={t.id} className={`ctab ${tab===t.id?"on":""}`} onClick={()=>setTab(t.id)}>{t.l}</button>)}
      </div>
      <button className="btn btn-gold btn-xs" onClick={()=>{setEditId(null);setFm({nome:"",tel:"",aniv:"",obs:""});setShowForm(true);}}>+ Cliente</button>
    </div>
    {/* PAINEL DE LIMPEZA */}
    {tab==="limpeza"&&inativas.length>0&&(<div style={{background:"linear-gradient(135deg,#fef2f2,#fff)",border:"1.5px solid #fecaca",borderRadius:12,padding:"16px 18px",marginBottom:14}}>
      <div style={{fontSize:14,fontWeight:700,color:"#dc2626",marginBottom:6}}>🗑 Limpeza da cartela de clientes</div>
      <div style={{fontSize:12,color:"#888",marginBottom:12,lineHeight:1.7}}>
        Estas <strong>{inativas.length} clientes</strong> nunca vieram ao salão ou não aparecem há mais de 1 ano.<br/>
        Selecione quem você quer remover da lista.
      </div>
      <div style={{display:"flex",gap:8,flexWrap:"wrap",marginBottom:12}}>
        <button className="btn btn-xs btn-ghost" onClick={()=>setSelLimpeza(new Set(inativas.map(c=>c.id)))}>✓ Selecionar todas</button>
        <button className="btn btn-xs btn-ghost" onClick={()=>setSelLimpeza(new Set())}>✕ Limpar seleção</button>
        {selLimpeza.size>0&&<button className="btn btn-xs" style={{background:"#dc2626",color:"#fff"}} onClick={()=>setConfirmLimpeza(true)}>
          🗑 Remover {selLimpeza.size} selecionada{selLimpeza.size>1?"s":""}
        </button>}
      </div>
      {selLimpeza.size>0&&<div style={{fontSize:11,color:"#dc2626",background:"#fef2f2",borderRadius:8,padding:"7px 12px"}}>
        ⚠️ Após remover, as clientes serão apagadas da lista. Agendamentos anteriores são mantidos.
      </div>}
    </div>)}

    {tab==="limpeza"&&inativas.length===0&&<div className="empty"><div className="empty-i">🎉</div><p>Nenhuma cliente inativa!<br/>Sua cartela está toda ativa.</p></div>}

    {filtrados.map(c=><div key={c.id} style={{background:tab==="limpeza"&&selLimpeza.has(c.id)?"#fef2f2":"#fff",borderRadius:12,border:`1.5px solid ${tab==="limpeza"&&selLimpeza.has(c.id)?"#fecaca":c.isAniv?"#f9a8d4":"#ebe8e0"}`,padding:"12px 16px",marginBottom:8,display:"flex",alignItems:"center",gap:12,cursor:"pointer"}} onClick={()=>{
  if(tab==="limpeza"){setSelLimpeza(prev=>{const n=new Set(prev);n.has(c.id)?n.delete(c.id):n.add(c.id);return n;});return;}
  setEditId(c.id);setFm({nome:c.nome,tel:c.tel,aniv:c.aniv||"",obs:c.obs||""});setShowForm(true);
}}>
      {tab==="limpeza"
        ? <div style={{width:40,height:40,borderRadius:"50%",background:selLimpeza.has(c.id)?"#fecaca":"#f0ece4",display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,flexShrink:0,border:`2px solid ${selLimpeza.has(c.id)?"#ef4444":"#e0dbd0"}`}}>
            {selLimpeza.has(c.id)?"✓":"○"}
          </div>
        : <div style={{width:40,height:40,borderRadius:"50%",background:c.isAniv?"linear-gradient(135deg,#ec4899,#db2777)":"linear-gradient(135deg,#f0e8d5,#e8d9be)",display:"flex",alignItems:"center",justifyContent:"center",fontWeight:700,fontSize:13,color:c.isAniv?"#fff":"#8a6f3e",flexShrink:0}}>
            {c.isAniv?"🎂":c.nome.split(" ").map(p=>p[0]).slice(0,2).join("").toUpperCase()}
          </div>
      }
      <div style={{flex:1,minWidth:0}}>
        <div style={{display:"flex",alignItems:"center",gap:6,flexWrap:"wrap"}}>
          <span style={{fontWeight:600,fontSize:13}}>{c.nome}</span>
          {c.isAniv&&<span className="tag tag-aniv">🎂 Aniversário!</span>}
          {c.reat&&<span style={{background:"#fffbeb",color:"#d97706",fontSize:10,fontWeight:700,padding:"2px 7px",borderRadius:10}}>💌 Reativar</span>}
        </div>
        <div style={{fontSize:11,color:"#aaa",marginTop:2}}>{c.tel}{c.aniv?` · 🎂 ${c.aniv.slice(8)}.${c.aniv.slice(5,7)}`:""}</div>
        <div style={{fontSize:11,color:"#aaa"}}>{c.visitas}x · R${c.total}{c.last?` · Último: ${fD(c.last.data)}`:""}{c.dias!==null?` (${c.dias}d)`:""}</div>
        {c.lastFicha&&<div style={{marginTop:3}}><span style={{fontSize:10,background:"#f5f3ff",color:"#7c3aed",padding:"2px 8px",borderRadius:8,fontWeight:700}}>💜 Última ficha: Dicollore {c.lastFicha.x}.{c.lastFicha.num} · {fD(c.lastFicha.data)}</span></div>}
        {c.reat&&c.lastSvc&&(c.lastSvc.alis||c.lastSvc.loiro)&&<div style={{fontSize:10,color:"#7c3aed",marginTop:2,fontWeight:600}}>💡 Retoque de {c.lastSvc.alis?"alisamento":"loiro"} indicado!</div>}
        {tab==="limpeza"&&c.nuncaVeio&&<div style={{fontSize:10,color:"#dc2626",marginTop:2,fontWeight:600}}>🚫 Nunca veio ao salão</div>}
        {tab==="limpeza"&&!c.nuncaVeio&&c.inativa&&<div style={{fontSize:10,color:"#dc2626",marginTop:2,fontWeight:600}}>📅 Última visita: {fD(c.last?.data)} ({c.dias} dias atrás)</div>}
      </div>
      <div style={{display:"flex",flexDirection:"column",gap:5,alignItems:"flex-end"}}>
        {c.isAniv&&<button className="btn btn-xs" style={{background:"#ec4899",color:"#fff"}} onClick={e=>{e.stopPropagation();openWA(c.tel,msgs.aniv(c.nome.split(" ")[0]));notify("🎂 WA enviado!","wa");}}>🎂</button>}
        {c.reat&&<button className="btn btn-xs" style={{background:"#fffbeb",color:"#d97706",border:"1px solid #fde68a"}} onClick={e=>{e.stopPropagation();openWA(c.tel,msgs.reat(c.nome.split(" ")[0],c.lastSvc,c.dias));notify("💌 WA enviado!");}}>💌</button>}
        <button className="btn btn-xs" style={{background:"#f5f3ff",color:"#7c3aed",border:"1px solid #ddd6fe"}} onClick={e=>{e.stopPropagation();onFicha(c);}}>💜 Ficha</button>
      </div>
    </div>)}
    {/* CONFIRM LIMPEZA MODAL */}
    {confirmLimpeza&&<div className="overlay" onClick={()=>setConfirmLimpeza(false)}>
      <div className="modal" style={{maxWidth:400}} onClick={e=>e.stopPropagation()}>
        <div className="modal-h">
          <div style={{fontSize:32,textAlign:"center",marginBottom:8}}>🗑</div>
          <div className="modal-t" style={{textAlign:"center"}}>Confirmar remoção</div>
          <div className="modal-s" style={{textAlign:"center"}}>Você selecionou <strong>{selLimpeza.size} cliente{selLimpeza.size>1?"s":""}</strong> para remover.<br/>Esta ação não pode ser desfeita.</div>
        </div>
        <div className="modal-b" style={{paddingBottom:12}}>
          <div style={{background:"#fef2f2",borderRadius:9,padding:"10px 14px",fontSize:12,color:"#dc2626",border:"1px solid #fecaca"}}>
            {enriched.filter(c=>selLimpeza.has(c.id)).map(c=><div key={c.id} style={{marginBottom:3}}>• {c.nome} {c.nuncaVeio?"(nunca veio)":`(${c.dias} dias sem visitar)`}</div>)}
          </div>
        </div>
        <div className="modal-f" style={{justifyContent:"space-between"}}>
          <button className="btn btn-ghost" onClick={()=>setConfirmLimpeza(false)}>Cancelar</button>
          <button className="btn" style={{background:"#dc2626",color:"#fff"}} onClick={()=>{
            setClientes(p=>p.filter(c=>!selLimpeza.has(c.id)));
            notify(`🗑 ${selLimpeza.size} cliente${selLimpeza.size>1?"s":""} removida${selLimpeza.size>1?"s":""}!`);
            setSelLimpeza(new Set());setConfirmLimpeza(false);setTab("todos");
          }}>🗑 Remover {selLimpeza.size}</button>
        </div>
      </div>
    </div>}

    {showForm&&<div className="overlay" onClick={e=>e.target===e.currentTarget&&setShowForm(false)}><div className="modal">
      <div className="modal-h"><div className="modal-t">{editId?"Editar":"Nova Cliente"}</div></div>
      <div className="modal-b">
        <div className="fg"><label className="fl">Nome</label><input className="fi" value={fm.nome} onChange={e=>upF("nome",e.target.value)} placeholder="Nome completo"/></div>
        <div className="fg"><label className="fl">WhatsApp</label><input className="fi" value={fm.tel} onChange={e=>upF("tel",e.target.value)} placeholder="16999999999"/></div>
        <div className="fg"><label className="fl">🎂 Nascimento</label><input type="date" className="fi" value={fm.aniv} onChange={e=>upF("aniv",e.target.value)}/></div>
        <div className="fg"><label className="fl">Observações</label><textarea className="fi" rows={3} value={fm.obs} onChange={e=>upF("obs",e.target.value)} placeholder="Alergias, preferências..."/></div>
      </div>
      <div className="modal-f"><button className="btn btn-ghost" onClick={()=>setShowForm(false)}>Cancelar</button><button className="btn btn-gold" disabled={!fm.nome||!fm.tel} onClick={salvar}>Salvar ✓</button></div>
    </div></div>}
  </>);
}

function FinanceiroView({apts}){
  const now=new Date();const [mes,setMes]=useState(now.getMonth());const [ano,setAno]=useState(now.getFullYear());
  const [contas,setContas]=useState(CONTAS_DEF);const [tab,setTab]=useState("resumo");
  const [showForm,setShowForm]=useState(false);const [editId,setEditId]=useState(null);
  const [fm,setFm]=useState({nome:"",valor:0,dia:1,cat:"outros"});
  const upF=(k,v)=>setFm(p=>({...p,[k]:v}));
  const mesNome=MESES[mes];
  const recMes=apts.filter(a=>{const[y,m]=(a.data||"").split("-");return Number(y)===ano&&Number(m)-1===mes&&a.status==="confirmado"&&!a.troca;}).reduce((s,a)=>s+(a.total||a.valor||0),0);
  const trocas=apts.filter(a=>{const[y,m]=(a.data||"").split("-");return Number(y)===ano&&Number(m)-1===mes&&a.troca;});
  const totalC=contas.reduce((s,c)=>s+(c.valor||0),0);         // total de todas as contas
  const totalP=contas.filter(c=>c.pago).reduce((s,c)=>s+(c.valor||0),0);   // total já pago
  const totalPend=totalC-totalP;                               // total pendente (a pagar)
  const lucro=recMes-totalP;    // lucro real = receita - só o que já saiu do bolso
  const diaH=now.getDate();
  const vSt=d=>{const diff=d-diaH;if(diff<0)return"late";if(diff<=5)return"warn";return"ok";};
  const vLb=d=>{const diff=d-diaH;if(diff<0)return`Venceu dia ${d}`;if(diff===0)return"Vence hoje!";if(diff===1)return"Vence amanhã";return`Vence dia ${d}`;};
  const pgMap={};apts.filter(a=>{const[y,m]=(a.data||"").split("-");return Number(y)===ano&&Number(m)-1===mes&&a.status==="confirmado"&&!a.troca;}).forEach(a=>{const p=a.pgto||"—";pgMap[p]=(pgMap[p]||0)+(a.total||a.valor||0);});
  const salvarConta=()=>{if(editId)setContas(p=>p.map(c=>c.id===editId?{...c,...fm}:c));else setContas(p=>[...p,{id:uid(),...fm,pago:false}]);setShowForm(false);setEditId(null);};
  return(<>
    <div style={{background:"linear-gradient(135deg,#1a1a1a,#2a2010)",borderRadius:13,padding:"18px 22px",marginBottom:16,color:"#fff",position:"relative",overflow:"hidden"}}>
      <div style={{position:"absolute",right:16,top:"50%",transform:"translateY(-50%)",fontFamily:"'Cormorant Garamond',serif",fontSize:70,color:"rgba(201,169,110,.08)"}}>R$</div>
      <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:12}}>
        <button onClick={()=>mes===0?(setMes(11),setAno(y=>y-1)):setMes(m=>m-1)} style={{background:"none",border:"1px solid #333",color:"#888",borderRadius:6,width:28,height:28,cursor:"pointer",fontSize:13}}>‹</button>
        <span style={{fontFamily:"'Cormorant Garamond',serif",fontSize:22,color:"#c9a96e"}}>{mesNome} {ano}</span>
        <button onClick={()=>mes===11?(setMes(0),setAno(y=>y+1)):setMes(m=>m+1)} style={{background:"none",border:"1px solid #333",color:"#888",borderRadius:6,width:28,height:28,cursor:"pointer",fontSize:13}}>›</button>
      </div>
      <div className="g3">
        <div style={{background:"rgba(255,255,255,.07)",borderRadius:9,padding:"10px 12px"}}>
          <div style={{fontSize:10,color:"#888",marginBottom:3}}>Receita</div>
          <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:22,fontWeight:600,color:"#4ade80"}}>R${recMes}</div>
        </div>
        <div style={{background:"rgba(255,255,255,.07)",borderRadius:9,padding:"10px 12px"}}>
          <div style={{fontSize:10,color:"#888",marginBottom:2}}>Despesas</div>
          <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:18,fontWeight:600,color:"#f87171"}}>R${totalP} <span style={{fontSize:12,color:"#888"}}>pago</span></div>
          <div style={{fontSize:11,color:"#fca5a5"}}>R${totalPend} a pagar</div>
        </div>
        <div style={{background:"rgba(255,255,255,.07)",borderRadius:9,padding:"10px 12px"}}>
          <div style={{fontSize:10,color:"#888",marginBottom:3}}>Lucro real</div>
          <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:22,fontWeight:600,color:lucro>=0?"#c9a96e":"#f87171"}}>{lucro<0?"-":""}R${Math.abs(lucro)}</div>
        </div>
      </div>
    </div>
    <div className="ctabs">
      {[{id:"resumo",l:"📊 Resumo"},{id:"receitas",l:"💰 Receitas"},{id:"contas",l:"📋 Contas"}].map(t=><button key={t.id} className={`ctab ${tab===t.id?"on":""}`} onClick={()=>setTab(t.id)}>{t.l}</button>)}
    </div>
    {tab==="resumo"&&(<>
      {/* Cards de resumo financeiro */}
      <div className="g4" style={{marginBottom:14}}>
        <div className="stat"><div className="stat-l">Receita</div><div className="stat-v gold">R${recMes}</div><div className="stat-s">{MESES[mes]}</div></div>
        <div className="stat"><div className="stat-l">Pago</div><div className="stat-v red">R${totalP}</div><div className="stat-s">despesas</div></div>
        <div className="stat"><div className="stat-l">A pagar</div><div className="stat-v" style={{color:"#dc2626"}}>R${totalPend}</div><div className="stat-s">pendente</div></div>
        <div className="stat"><div className="stat-l">Lucro real</div><div className="stat-v" style={{color:lucro>=0?"#16a34a":"#ef4444"}}>{lucro<0?"-":""}R${Math.abs(lucro)}</div><div className="stat-s">no bolso</div></div>
      </div>

      {trocas.length>0&&<div style={{background:"#f0fdf4",border:"1px solid #86efac",borderRadius:12,padding:"12px 16px",marginBottom:14}}>
        <div style={{fontSize:13,fontWeight:700,color:"#16a34a",marginBottom:6}}>🔄 Trocas em {mesNome}: {trocas.length}</div>
        {trocas.map(a=><div key={a.id} style={{display:"flex",justifyContent:"space-between",fontSize:12,color:"#555",marginBottom:3}}><span>{a.cliente} · {a.servico}</span><span style={{color:"#16a34a",fontWeight:600}}>{fD(a.data)}</span></div>)}
        <div style={{marginTop:6,fontSize:11,color:"#888"}}>✅ Trocas não contabilizam no faturamento</div>
      </div>}
      <div className="card">
        <div className="card-h"><span className="card-t">💳 Por forma de pagamento</span></div>
        <div className="card-b">
          {Object.keys(pgMap).length===0?<div className="empty"><div className="empty-i">💳</div><p>Sem receitas finalizadas</p></div>
           :Object.entries(pgMap).map(([p,v])=><div key={p} style={{display:"flex",alignItems:"center",gap:10,marginBottom:10}}>
              <span style={{fontSize:12,fontWeight:500,width:75,flexShrink:0}}>{p==="pix"?"PIX":p==="dinheiro"?"Dinheiro":p==="debito"?"Débito":p==="credito"?"Crédito":p}</span>
              <div className="sbar"><div className="sbar-f" style={{width:recMes>0?`${Math.round((v/recMes)*100)}%`:"0%",background:p==="pix"?"#25d366":p==="dinheiro"?"#c9a96e":p==="debito"?"#3b82f6":"#7c3aed"}}/></div>
              <span style={{fontFamily:"'Cormorant Garamond',serif",fontSize:16,color:"#c9a96e",fontWeight:600,flexShrink:0}}>R${v}</span>
           </div>)}
        </div>
      </div>
    </>)}
    {tab==="receitas"&&<div className="card"><div className="card-h"><span className="card-t">💰 {mesNome}</span><span style={{fontFamily:"'Cormorant Garamond',serif",fontSize:18,color:"#c9a96e",fontWeight:600}}>R${recMes}</span></div>
      <div className="card-b" style={{padding:0}}><div style={{overflowX:"auto"}}><table className="tbl"><thead><tr><th>Cliente</th><th>Serviço</th><th>Data</th><th>Pgto</th><th>Total</th></tr></thead>
        <tbody>{apts.filter(a=>{const[y,m]=(a.data||"").split("-");return Number(y)===ano&&Number(m)-1===mes&&a.status==="confirmado"&&!a.troca;}).sort((a,b)=>a.data>b.data?1:-1).map(a=><tr key={a.id}><td style={{fontWeight:500}}>{a.cliente}</td><td style={{fontSize:12}}>{a.servico}</td><td>{fD(a.data)}</td><td style={{fontSize:11,fontWeight:700,color:a.pgto==="pix"?"#25d366":a.pgto==="dinheiro"?"#c9a96e":"#7c3aed"}}>{a.pgto?.toUpperCase()||"—"}</td><td style={{fontFamily:"'Cormorant Garamond',serif",fontSize:16,color:"#c9a96e",fontWeight:600}}>R${a.total||a.valor}</td></tr>)}
        </tbody></table></div>
        {apts.filter(a=>{const[y,m]=(a.data||"").split("-");return Number(y)===ano&&Number(m)-1===mes&&a.status==="confirmado"&&!a.troca;}).length===0&&<div className="empty"><div className="empty-i">💰</div><p>Sem receitas</p></div>}
      </div>
    </div>}
    {tab==="contas"&&(<>
      {/* Barra de progresso de pagamentos */}
      <div style={{background:"#fff",borderRadius:12,border:"1px solid #ebe8e0",padding:"14px 18px",marginBottom:14}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8,flexWrap:"wrap",gap:6}}>
          <div style={{fontSize:13,fontWeight:700}}>Controle de Pagamentos</div>
          <button className="btn btn-gold btn-xs" onClick={()=>{setEditId(null);setFm({nome:"",valor:0,dia:1,cat:"outros"});setShowForm(true);}}>+ Conta</button>
        </div>
        <div style={{display:"flex",gap:8,marginBottom:10,flexWrap:"wrap"}}>
          <div style={{background:"#f0fdf4",borderRadius:8,padding:"7px 14px",fontSize:13,color:"#16a34a",fontWeight:700}}>✓ Pago: R${totalP}</div>
          <div style={{background:"#fef2f2",borderRadius:8,padding:"7px 14px",fontSize:13,color:"#dc2626",fontWeight:700}}>⏳ A pagar: R${totalPend}</div>
          <div style={{background:"#f7f5f0",borderRadius:8,padding:"7px 14px",fontSize:13,color:"#888",fontWeight:600}}>Total: R${totalC}</div>
        </div>
        {totalC>0&&<div>
          <div style={{background:"#f0ece4",borderRadius:20,height:10,overflow:"hidden"}}>
            <div style={{width:`${Math.round((totalP/totalC)*100)}%`,height:"100%",background:"linear-gradient(90deg,#22c55e,#86efac)",borderRadius:20,transition:"width .5s"}}/>
          </div>
          <div style={{fontSize:11,color:"#aaa",marginTop:4,textAlign:"right"}}>{Math.round((totalP/totalC)*100)}% pago</div>
        </div>}
      </div>
      {["aluguel","util","fornec","outros"].map(cat=>{
        const cats=contas.filter(c=>c.cat===cat);if(!cats.length)return null;
        const CL={aluguel:"🏠 Aluguel",util:"💡 Utilidades",fornec:"📦 Fornecedores",outros:"📌 Outros"};
        return(<div key={cat} className="card"><div className="card-h"><span className="card-t">{CL[cat]}</span><span style={{fontFamily:"'Cormorant Garamond',serif",fontSize:16,color:"#c9a96e",fontWeight:600}}>R${cats.reduce((s,c)=>s+c.valor,0)}</span></div>
          <div className="card-b" style={{padding:"0 18px"}}>
            {cats.map(c=><div key={c.id} className="row" style={{background:c.pago?"#fafffe":"#fff",borderRadius:8,padding:"8px 4px"}}>
              <div style={{flex:1}}>
                <div style={{fontSize:13,fontWeight:500,color:c.pago?"#aaa":"#1a1a1a",textDecoration:c.pago?"line-through":"none"}}>{c.nome}</div>
                <div style={{marginTop:3}}><span style={{fontSize:11,padding:"2px 8px",borderRadius:12,fontWeight:600,background:vSt(c.dia)==="late"?"#fef2f2":vSt(c.dia)==="warn"?"#fffbeb":"#f0fdf4",color:vSt(c.dia)==="late"?"#dc2626":vSt(c.dia)==="warn"?"#d97706":"#16a34a"}}>{vLb(c.dia)}</span></div>
              </div>
              <div style={{textAlign:"right",display:"flex",alignItems:"center",gap:8}}>
                <div><div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:16,fontWeight:600,color:c.pago?"#aaa":"#1a1a1a"}}>R${c.valor}</div>
                  <button onClick={()=>setContas(p=>p.map(x=>x.id===c.id?{...x,pago:!x.pago,dataPago:!x.pago?hj():null}:x))}
                    style={{fontSize:11,background:c.pago?"#16a34a":"linear-gradient(135deg,#c9a96e,#b8935a)",color:"#fff",border:"none",borderRadius:9,padding:"5px 12px",cursor:"pointer",fontFamily:"'DM Sans',sans-serif",fontWeight:700,boxShadow:c.pago?"none":"0 2px 6px rgba(201,169,110,.3)"}}>
                    {c.pago?"✓ Pago":"💳 Pagar agora"}
                  </button>
                  {c.pago&&c.dataPago&&<div style={{fontSize:10,color:"#aaa"}}>em {fD(c.dataPago)}</div>}
                </div>
                <div style={{display:"flex",flexDirection:"column",gap:4}}>
                  <button className="btn btn-ghost btn-xs" onClick={()=>{setEditId(c.id);setFm({nome:c.nome,valor:c.valor,dia:c.dia,cat:c.cat});setShowForm(true);}}>✏️</button>
                  <button className="btn btn-red btn-xs" onClick={()=>setContas(p=>p.filter(x=>x.id!==c.id))}>🗑</button>
                </div>
              </div>
            </div>)}
          </div>
        </div>);
      })}
    </>)}
    {/* CONFIRM LIMPEZA MODAL */}
    {confirmLimpeza&&<div className="overlay" onClick={()=>setConfirmLimpeza(false)}>
      <div className="modal" style={{maxWidth:400}} onClick={e=>e.stopPropagation()}>
        <div className="modal-h">
          <div style={{fontSize:32,textAlign:"center",marginBottom:8}}>🗑</div>
          <div className="modal-t" style={{textAlign:"center"}}>Confirmar remoção</div>
          <div className="modal-s" style={{textAlign:"center"}}>Você selecionou <strong>{selLimpeza.size} cliente{selLimpeza.size>1?"s":""}</strong> para remover.<br/>Esta ação não pode ser desfeita.</div>
        </div>
        <div className="modal-b" style={{paddingBottom:12}}>
          <div style={{background:"#fef2f2",borderRadius:9,padding:"10px 14px",fontSize:12,color:"#dc2626",border:"1px solid #fecaca"}}>
            {enriched.filter(c=>selLimpeza.has(c.id)).map(c=><div key={c.id} style={{marginBottom:3}}>• {c.nome} {c.nuncaVeio?"(nunca veio)":`(${c.dias} dias sem visitar)`}</div>)}
          </div>
        </div>
        <div className="modal-f" style={{justifyContent:"space-between"}}>
          <button className="btn btn-ghost" onClick={()=>setConfirmLimpeza(false)}>Cancelar</button>
          <button className="btn" style={{background:"#dc2626",color:"#fff"}} onClick={()=>{
            setClientes(p=>p.filter(c=>!selLimpeza.has(c.id)));
            notify(`🗑 ${selLimpeza.size} cliente${selLimpeza.size>1?"s":""} removida${selLimpeza.size>1?"s":""}!`);
            setSelLimpeza(new Set());setConfirmLimpeza(false);setTab("todos");
          }}>🗑 Remover {selLimpeza.size}</button>
        </div>
      </div>
    </div>}

    {showForm&&<div className="overlay" onClick={e=>e.target===e.currentTarget&&setShowForm(false)}><div className="modal">
      <div className="modal-h"><div className="modal-t">{editId?"Editar":"Nova Conta"}</div></div>
      <div className="modal-b">
        <div className="fg"><label className="fl">Nome</label><input className="fi" value={fm.nome} onChange={e=>upF("nome",e.target.value)} placeholder="Ex: Aluguel do salão"/></div>
        <div className="fi-row"><div className="fg"><label className="fl">Valor R$</label><input type="number" className="fi" value={fm.valor} onChange={e=>upF("valor",Number(e.target.value))}/></div><div className="fg"><label className="fl">Vence dia</label><input type="number" min={1} max={31} className="fi" value={fm.dia} onChange={e=>upF("dia",Number(e.target.value))}/></div></div>
        <div className="fg"><label className="fl">Categoria</label><select className="fi" value={fm.cat} onChange={e=>upF("cat",e.target.value)}><option value="aluguel">🏠 Aluguel</option><option value="util">💡 Utilidades</option><option value="fornec">📦 Fornecedor</option><option value="outros">📌 Outros</option></select></div>
      </div>
      <div className="modal-f"><button className="btn btn-ghost" onClick={()=>setShowForm(false)}>Cancelar</button><button className="btn btn-gold" disabled={!fm.nome||fm.valor===0} onClick={salvarConta}>Salvar ✓</button></div>
    </div></div>}
  </>);
}

function MetasView({apts,clientes,notify}){
  const now=new Date();const mes=now.getMonth();const ano=now.getFullYear();
  const [tab,setTab]=useState("painel");
  const diasRestantes=new Date(ano,mes+1,0).getDate()-now.getDate();
  const recMes=apts.filter(a=>{const[y,m]=(a.data||"").split("-");return Number(y)===ano&&Number(m)-1===mes&&a.status==="confirmado"&&!a.troca;}).reduce((s,a)=>s+(a.total||a.valor||0),0);
  const pct=Math.min(100,Math.round((recMes/META)*100));const falta=Math.max(0,META-recMes);
  const nA=apts.filter(a=>{const[y,m]=(a.data||"").split("-");return Number(y)===ano&&Number(m)-1===mes&&a.status==="confirmado"&&!a.troca;}).length;
  const ticket=nA>0?Math.round(recMes/nA):250;const necessarias=ticket>0?Math.ceil(falta/ticket):0;
  const iniMes=`${ano}-${s2(mes+1)}-01`;
  const captacao=useMemo(()=>{
    const hMap={};apts.filter(a=>a.status==="confirmado"&&!a.troca).forEach(a=>{if(!hMap[a.cliente])hMap[a.cliente]={total:0,v:0,last:null,lastSvc:null};hMap[a.cliente].total+=(a.total||a.valor||0);hMap[a.cliente].v++;if(!hMap[a.cliente].last||a.data>hMap[a.cliente].last)hMap[a.cliente].last=a.data;hMap[a.cliente].lastSvc=a.servico;});
    return clientes.filter(c=>c.tel).map(c=>{
      const h=hMap[c.nome]||{total:0,v:0,last:null,lastSvc:null};
      const tick=h.v>0?Math.round(h.total/h.v):0;
      const dias=h.last?Math.floor((new Date()-new Date(h.last))/(1000*60*60*24)):999;
      const veioMes=apts.some(a=>a.cliente===c.nome&&a.data>=iniMes&&a.status==="confirmado");
      const lastSvcObj=h.lastSvc?SERVICOS.find(s=>s.nome===h.lastSvc):null;
      const retoque=lastSvcObj&&(lastSvcObj.alis||lastSvcObj.loiro)&&dias>=60;
      if(veioMes)return null;
      let sc=0;if(tick>=400)sc+=50;else if(tick>=200)sc+=30;else if(tick>0)sc+=15;if(dias>=60)sc+=30;if(dias>=90)sc+=20;if(retoque)sc+=25;sc+=15;
      if(sc===0)return null;
      const pri=sc>=80?"alta":sc>=40?"media":"baixa";
      return{...c,sc,pri,tick,dias,retoque,lastSvcObj};
    }).filter(Boolean).sort((a,b)=>b.sc-a.sc);
  },[apts,clientes,mes,ano]);
  const gerarMsg=c=>{
    if(c.retoque)return msgs.reat(c.nome.split(" ")[0],c.lastSvcObj,c.dias);
    if(c.dias>=90)return msgs.reat(c.nome.split(" ")[0],null,c.dias);
    return `Oi ${c.nome.split(" ")[0]}! 🌸\n\nSentimos sua falta no *Estúdio Madame*! 💇‍♀️\n\nAinda temos horários disponíveis essa semana!\n\n📍 ${ENDERECO}\n📅 Ter–Sáb · 08h30–18h\n\n— Evelyn Ramos`;
  };
  const disparar=grupo=>{grupo.slice(0,10).forEach((c,i)=>setTimeout(()=>openWA(c.tel,gerarMsg(c)),i*1500));notify(`🚀 Disparando para ${Math.min(10,grupo.length)} clientes!`,"wa");};
  return(<>
    <div style={{background:"linear-gradient(135deg,#1a1208,#2a1a08)",borderRadius:14,padding:"20px 22px",marginBottom:16,color:"#fff",position:"relative",overflow:"hidden"}}>
      <div style={{position:"absolute",right:16,top:"50%",transform:"translateY(-50%)",fontSize:64,opacity:.1}}>🎯</div>
      <div style={{fontSize:11,color:"#888",textTransform:"uppercase",letterSpacing:1,marginBottom:6}}>Meta — {MESES[mes]} {ano}</div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-end",marginBottom:4}}>
        <div><div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:32,fontWeight:600,color:"#4ade80",lineHeight:1}}>R${recMes.toLocaleString("pt-BR")}</div><div style={{fontSize:12,color:"#888",marginTop:3}}>de R${META.toLocaleString("pt-BR")}</div></div>
        <div style={{textAlign:"right"}}><div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:26,color:pct>=100?"#4ade80":pct>=70?"#fbbf24":"#f87171",fontWeight:600}}>{pct}%</div><div style={{fontSize:11,color:"#888"}}>{diasRestantes}d restantes</div></div>
      </div>
      <div className="meta-bar"><div className="meta-fill" style={{width:`${pct}%`,background:pct>=70?"linear-gradient(90deg,#22c55e,#86efac)":pct>=40?"linear-gradient(90deg,#f59e0b,#fde68a)":"linear-gradient(90deg,#ef4444,#fca5a5)"}}/></div>
      <div className="g3" style={{marginTop:12}}>
        {[["Falta",`R$${falta}`],["Ticket",`R$${ticket}`],["Clientes",String(necessarias)]].map(([l,v])=><div key={l} style={{background:"rgba(255,255,255,.07)",borderRadius:8,padding:"9px 10px",textAlign:"center"}}><div style={{fontSize:10,color:"#888",marginBottom:3}}>{l}</div><div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:18,color:"#c9a96e",fontWeight:600}}>{v}</div></div>)}
      </div>
    </div>
    <div className="ctabs">
      {[{id:"painel",l:"📊 Painel"},{id:"captar",l:`💌 Captar (${captacao.length})`},{id:"disparar",l:"🚀 Disparar"}].map(t=><button key={t.id} className={`ctab ${tab===t.id?"on":""}`} onClick={()=>setTab(t.id)}>{t.l}</button>)}
    </div>
    {tab==="painel"&&<div className="card"><div className="card-h"><span className="card-t">📈 Situação atual</span></div><div className="card-b">
      {[["Meta mensal",`R$${META.toLocaleString("pt-BR")}`],["Faturado",`R$${recMes.toLocaleString("pt-BR")}`],["Falta",`R$${falta.toLocaleString("pt-BR")}`],["Dias restantes",`${diasRestantes} dias`],["Ticket médio",`R$${ticket}`],["Clientes necessárias",`${necessarias}`]].map(([l,v])=><div key={l} style={{display:"flex",justifyContent:"space-between",padding:"9px 0",borderBottom:"1px solid #f5f3ee"}}><span style={{fontSize:13,color:"#666"}}>{l}</span><span style={{fontFamily:"'Cormorant Garamond',serif",fontSize:17,color:"#c9a96e",fontWeight:600}}>{v}</span></div>)}
    </div></div>}
    {tab==="captar"&&(<>
      <div style={{background:"#f7f5f0",borderRadius:10,padding:"11px 14px",marginBottom:12,fontSize:12,color:"#888"}}>🤖 Clientes priorizadas por maior ticket, mais tempo sem visitar e necessidade de retoque.</div>
      {captacao.length===0?<div className="empty"><div className="empty-i">🎉</div><p>Todas as clientes vieram esse mês!</p></div>
       :captacao.slice(0,25).map(c=><div key={c.id} className={`capt-card ${c.pri}`}>
          <div style={{width:34,height:34,borderRadius:"50%",background:c.pri==="alta"?"#fef2f2":c.pri==="media"?"#fffbeb":"#f0fdf4",display:"flex",alignItems:"center",justifyContent:"center",fontWeight:700,fontSize:12,color:c.pri==="alta"?"#dc2626":c.pri==="media"?"#d97706":"#16a34a",flexShrink:0}}>{c.sc}</div>
          <div style={{flex:1,minWidth:0}}>
            <div style={{fontWeight:600,fontSize:13}}>{c.nome}</div>
            <div style={{fontSize:11,color:"#aaa"}}>{c.tick>0?`R$${c.tick} ticket`:""}{c.dias<999?` · ${c.dias}d sem visitar`:""}{c.retoque?" · 💡 retoque!":""}</div>
          </div>
          <button className="btn btn-wa btn-xs" onClick={()=>{openWA(c.tel,gerarMsg(c));notify(`📱 WA para ${c.nome}!`,"wa");}}>📱</button>
        </div>)}
    </>)}
    {tab==="disparar"&&<>
      <div style={{background:"linear-gradient(135deg,#fef2f2,#fff)",border:"1.5px solid #fecaca",borderRadius:12,padding:"16px 18px",marginBottom:14}}>
        <div style={{fontSize:14,fontWeight:700,color:"#dc2626",marginBottom:10}}>🚀 Disparo em massa</div>
        <div className="g4" style={{marginBottom:14}}>
          {[["🔴 Alta",captacao.filter(c=>c.pri==="alta").length,"#fef2f2","#ef4444"],["🟡 Média",captacao.filter(c=>c.pri==="media").length,"#fffbeb","#d97706"],["🟢 Baixa",captacao.filter(c=>c.pri==="baixa").length,"#f0fdf4","#16a34a"],["📊 Total",captacao.length,"#f5f3ff","#7c3aed"]].map(([l,n,bg,cor])=><div key={l} style={{background:bg,borderRadius:9,padding:"10px 12px"}}><div style={{fontSize:11,color:"#888",marginBottom:2}}>{l}</div><div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:22,fontWeight:600,color:cor}}>{n}</div></div>)}
        </div>
        {[["🔴 Só alta prioridade",captacao.filter(c=>c.pri==="alta")],["🟡 Alta + Média",captacao.filter(c=>c.pri==="alta"||c.pri==="media")],["🚀 TODAS",captacao]].map(([l,g])=><button key={l} disabled={g.length===0} onClick={()=>disparar(g)} style={{width:"100%",padding:13,background:l.includes("TODAS")?"linear-gradient(135deg,#c9a96e,#b8935a)":"#fff",color:l.includes("TODAS")?"#fff":"#333",border:"1.5px solid #e0dbd0",borderRadius:10,fontFamily:"'DM Sans',sans-serif",fontSize:13,fontWeight:600,cursor:g.length===0?"not-allowed":"pointer",opacity:g.length===0?.5:1,textAlign:"left",marginBottom:8}}>{l} ({Math.min(10,g.length)} clientes)</button>)}
      </div>
    </>}
  </>);
}

function MensagensView(){
  const [exp,setExp]=useState(null);const [editId,setEditId]=useState(null);const [editTxt,setEditTxt]=useState("");
  const ex={n:"Ana Lima",s:"Progressiva My Horizon (Retoque)",d:"15/04/2026",h:"10:00",v:280};
  const DEF=[
    {id:"conf",icon:"✅",label:"Confirmação",       tag:"automática",cor:"#25d366",txt:msgs.confirm(ex.n,ex.s,ex.d,ex.h,ex.v)},
    {id:"lemb",icon:"⏰",label:"Lembrete",          tag:"automática",cor:"#f59e0b",txt:msgs.lembrete(ex.n,ex.s,ex.h)},
    {id:"alis",icon:"🌊",label:"Pós-Alisamento",    tag:"pós-química",cor:"#3b82f6",txt:msgs.posAlis(ex.n,ex.s)},
    {id:"loiro",icon:"👱",label:"Pós-Loiro",        tag:"pós-química",cor:"#f59e0b",txt:msgs.posLoiro(ex.n)},
    {id:"aniv",icon:"🎂",label:"Aniversário",       tag:"aniversário",cor:"#ec4899",txt:msgs.aniv(ex.n)},
    {id:"reat",icon:"💌",label:"Reativação",        tag:"automática",cor:"#7c3aed",txt:msgs.reat(ex.n,null,120)},
    {id:"bonif",icon:"🏆",label:"Bonificação VIP",  tag:"manual",     cor:"#c9a96e",txt:msgs.bonif(ex.n)},
  ];
  const [ms2,setMs2]=useState(DEF);
  const editado=id=>ms2.find(m=>m.id===id)?.txt!==DEF.find(m=>m.id===id)?.txt;
  return(<>
    <div style={{background:"linear-gradient(135deg,#e9f5e1,#f0fdf4)",borderRadius:12,padding:"14px 18px",marginBottom:14,border:"1px solid #bbf7d0"}}>
      <div style={{fontSize:13,fontWeight:700,color:"#16a34a",marginBottom:4}}>📱 Central de Mensagens WhatsApp</div>
      <div style={{fontSize:11,color:"#666"}}>Clique em ✏️ para editar e salvar do seu jeito!</div>
    </div>
    {ms2.map(m=><div key={m.id} style={{background:"#fff",borderRadius:12,border:"1px solid #ebe8e0",marginBottom:10,overflow:"hidden"}}>
      <div style={{padding:"12px 16px",display:"flex",alignItems:"center",gap:10,borderBottom:exp===m.id?"1px solid #f0ece4":"none",cursor:"pointer"}} onClick={()=>setExp(exp===m.id?null:m.id)}>
        <span style={{fontSize:20}}>{m.icon}</span>
        <div style={{flex:1}}><div style={{display:"flex",alignItems:"center",gap:6}}><span style={{fontWeight:600,fontSize:13}}>{m.label}</span>{editado(m.id)&&<span style={{background:"#fffbeb",color:"#d97706",fontSize:10,fontWeight:700,padding:"1px 6px",borderRadius:8}}>✏️ editada</span>}</div><span style={{fontSize:10,background:`${m.cor}22`,color:m.cor,padding:"2px 8px",borderRadius:12,fontWeight:600,marginTop:3,display:"inline-block"}}>{m.tag}</span></div>
        <span style={{color:"#ccc",fontSize:12}}>{exp===m.id?"▲":"▼"}</span>
      </div>
      {exp===m.id&&<div style={{padding:"14px 16px"}}>
        {editId===m.id?(<>
          <textarea value={editTxt} onChange={e=>setEditTxt(e.target.value)} rows={10} style={{width:"100%",padding:"10px 12px",border:"1.5px solid #7c3aed",borderRadius:9,fontFamily:"'DM Sans',sans-serif",fontSize:12,lineHeight:1.7,outline:"none",resize:"vertical"}}/>
          <div style={{display:"flex",gap:8,marginTop:10}}>
            <button className="btn btn-purple btn-xs" onClick={()=>{setMs2(p=>p.map(x=>x.id===m.id?{...x,txt:editTxt}:x));setEditId(null);}}>💾 Salvar</button>
            <button className="btn btn-ghost btn-xs" onClick={()=>setEditId(null)}>Cancelar</button>
            {editado(m.id)&&<button className="btn btn-red btn-xs" onClick={()=>{setMs2(p=>p.map(x=>x.id===m.id?{...x,txt:DEF.find(d=>d.id===m.id)?.txt||""}:x));setEditId(null);}}>↩️ Restaurar</button>}
          </div>
        </>):(<>
          <div style={{background:"#e9f5e1",borderRadius:10,padding:"11px 13px",fontSize:11,lineHeight:1.7,color:"#333",whiteSpace:"pre-wrap"}}>{m.txt}</div>
          <div style={{display:"flex",gap:8,marginTop:10}}>
            <button className="btn btn-purple btn-xs" onClick={()=>{setEditId(m.id);setEditTxt(m.txt);}}>✏️ Editar</button>
            <button className="btn btn-ghost btn-xs" onClick={()=>navigator.clipboard?.writeText(m.txt)}>📋 Copiar</button>
            <button className="btn btn-wa btn-xs" onClick={()=>openWA(WA_NUM,m.txt)}>📱 Testar</button>
          </div>
        </>)}
      </div>}
    </div>)}
  </>);
}

function EstoqueView({stock,setStock}){
  const [busca,setBusca]=useState("");
  const [showForm,setShowForm]=useState(false);const [editId,setEditId]=useState(null);
  const [fm,setFm]=useState({nome:"",marca:"Dicolore",qtd:0,min:50,custo:0,unit:"ml"});
  const upF=(k,v)=>setFm(p=>({...p,[k]:v}));
  const alertas=stock.filter(s=>s.qtd<=s.min);
  const criticos=stock.filter(s=>s.qtd===0);
  const urgentes=stock.filter(s=>s.qtd>0&&s.qtd<=s.min);
  const filtrado=stock.filter(s=>s.nome.toLowerCase().includes(busca.toLowerCase()));
  const salvar=()=>{if(editId)setStock(p=>p.map(s=>s.id===editId?{...s,...fm}:s));else setStock(p=>[...p,{id:uid(),...fm}]);setShowForm(false);setEditId(null);};
  return(<>
    {criticos.length>0&&<div style={{background:"#fef2f2",border:"1.5px solid #ef4444",borderRadius:11,padding:"12px 16px",marginBottom:10,display:"flex",alignItems:"flex-start",gap:10}}>
      <span style={{fontSize:20}}>🚨</span>
      <div>
        <div style={{fontSize:13,fontWeight:700,color:"#dc2626",marginBottom:4}}>Zerado — Comprar urgente!</div>
        <div style={{fontSize:12,color:"#ef4444"}}>{criticos.map(a=>a.nome).join(" · ")}</div>
      </div>
    </div>}
    {urgentes.length>0&&<div style={{background:"#fffbeb",border:"1px solid #fde68a",borderRadius:11,padding:"12px 16px",marginBottom:10,display:"flex",alignItems:"flex-start",gap:10}}>
      <span style={{fontSize:20}}>⚠️</span>
      <div>
        <div style={{fontSize:13,fontWeight:700,color:"#d97706",marginBottom:4}}>Estoque baixo — atenção!</div>
        <div style={{fontSize:12,color:"#b45309"}}>{urgentes.map(a=>`${a.nome} (${a.qtd}${a.unit})`).join(" · ")}</div>
      </div>
    </div>}
    <div style={{display:"flex",gap:8,marginBottom:12,alignItems:"center"}}>
      <input className="fi" style={{flex:1}} placeholder="🔍 Buscar..." value={busca} onChange={e=>setBusca(e.target.value)}/>
      <button className="btn btn-gold btn-xs" onClick={()=>{setEditId(null);setFm({nome:"",marca:"Dicolore",qtd:0,min:50,custo:0,unit:"ml"});setShowForm(true);}}>+ Produto</button>
    </div>
    <div className="card"><div className="card-b" style={{padding:0}}>
      {filtrado.map(s=>{const pct=Math.min(100,Math.round((s.qtd/(s.min*3||1))*100));const low=s.qtd<=s.min;return<div key={s.id} className="row" style={{padding:"10px 18px"}}>
        <div style={{width:34,height:34,borderRadius:8,background:s.marca==="Dicolore"?"#f0e8ff":"#e8f0ff",display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,flexShrink:0}}>{s.marca==="Dicolore"?"💜":"💙"}</div>
        <div style={{flex:1,minWidth:0}}>
          <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:2}}><span style={{fontWeight:600,fontSize:13}}>{s.nome}</span>{low&&<span style={{background:"#fef2f2",color:"#dc2626",fontSize:9,fontWeight:700,padding:"1px 6px",borderRadius:8}}>BAIXO</span>}</div>
          <div style={{fontSize:11,color:"#aaa",marginBottom:4}}>{s.marca}</div>
          <div style={{display:"flex",alignItems:"center",gap:7}}>
            <div className="sbar"><div className="sbar-f" style={{width:`${pct}%`,background:pct>50?"#22c55e":pct>20?"#f59e0b":"#ef4444"}}/></div>
            <span style={{fontSize:10,color:"#888",flexShrink:0}}>{s.qtd}/{s.min*3}{s.unit}</span>
          </div>
        </div>
        <div style={{textAlign:"right",flexShrink:0}}>
          <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:13,color:"#c9a96e",fontWeight:600}}>R${s.custo}</div>
          <div style={{display:"flex",gap:4,marginTop:4}}><button className="btn btn-ghost btn-xs" onClick={()=>{setEditId(s.id);setFm({nome:s.nome,marca:s.marca,qtd:s.qtd,min:s.min,custo:s.custo,unit:s.unit});setShowForm(true);}}>✏️</button><button className="btn btn-red btn-xs" onClick={()=>setStock(p=>p.filter(x=>x.id!==s.id))}>🗑</button></div>
        </div>
      </div>;})}
    </div></div>
    {/* CONFIRM LIMPEZA MODAL */}
    {confirmLimpeza&&<div className="overlay" onClick={()=>setConfirmLimpeza(false)}>
      <div className="modal" style={{maxWidth:400}} onClick={e=>e.stopPropagation()}>
        <div className="modal-h">
          <div style={{fontSize:32,textAlign:"center",marginBottom:8}}>🗑</div>
          <div className="modal-t" style={{textAlign:"center"}}>Confirmar remoção</div>
          <div className="modal-s" style={{textAlign:"center"}}>Você selecionou <strong>{selLimpeza.size} cliente{selLimpeza.size>1?"s":""}</strong> para remover.<br/>Esta ação não pode ser desfeita.</div>
        </div>
        <div className="modal-b" style={{paddingBottom:12}}>
          <div style={{background:"#fef2f2",borderRadius:9,padding:"10px 14px",fontSize:12,color:"#dc2626",border:"1px solid #fecaca"}}>
            {enriched.filter(c=>selLimpeza.has(c.id)).map(c=><div key={c.id} style={{marginBottom:3}}>• {c.nome} {c.nuncaVeio?"(nunca veio)":`(${c.dias} dias sem visitar)`}</div>)}
          </div>
        </div>
        <div className="modal-f" style={{justifyContent:"space-between"}}>
          <button className="btn btn-ghost" onClick={()=>setConfirmLimpeza(false)}>Cancelar</button>
          <button className="btn" style={{background:"#dc2626",color:"#fff"}} onClick={()=>{
            setClientes(p=>p.filter(c=>!selLimpeza.has(c.id)));
            notify(`🗑 ${selLimpeza.size} cliente${selLimpeza.size>1?"s":""} removida${selLimpeza.size>1?"s":""}!`);
            setSelLimpeza(new Set());setConfirmLimpeza(false);setTab("todos");
          }}>🗑 Remover {selLimpeza.size}</button>
        </div>
      </div>
    </div>}

    {showForm&&<div className="overlay" onClick={e=>e.target===e.currentTarget&&setShowForm(false)}><div className="modal"><div className="modal-h"><div className="modal-t">{editId?"Editar":"Novo Produto"}</div></div><div className="modal-b">
      <div className="fg"><label className="fl">Nome</label><input className="fi" value={fm.nome} onChange={e=>upF("nome",e.target.value)} placeholder="Ex: Shampoo Botox"/></div>
      <div className="fg"><label className="fl">Marca</label><select className="fi" value={fm.marca} onChange={e=>upF("marca",e.target.value)}><option>Dicolore</option><option>Robson Peluquero</option><option>Outra</option></select></div>
      <div className="fi-row"><div className="fg"><label className="fl">Qtd. atual</label><input type="number" className="fi" value={fm.qtd} onChange={e=>upF("qtd",Number(e.target.value))}/></div><div className="fg"><label className="fl">Alerta mín.</label><input type="number" className="fi" value={fm.min} onChange={e=>upF("min",Number(e.target.value))}/></div></div>
      <div className="fi-row"><div className="fg"><label className="fl">Custo R$</label><input type="number" className="fi" value={fm.custo} onChange={e=>upF("custo",Number(e.target.value))}/></div><div className="fg"><label className="fl">Unidade</label><select className="fi" value={fm.unit} onChange={e=>upF("unit",e.target.value)}><option value="ml">ml</option><option value="g">g</option><option value="un">unidade</option></select></div></div>
    </div><div className="modal-f"><button className="btn btn-ghost" onClick={()=>setShowForm(false)}>Cancelar</button><button className="btn btn-gold" disabled={!fm.nome} onClick={salvar}>Salvar ✓</button></div></div></div>}
  </>);
}

function ComprasView({fichas}){
  const now=new Date();const mes=now.getMonth();const ano=now.getFullYear();
  const fichasMes=fichas.filter(f=>{const[y,m]=(f.data||"").split("-");return Number(y)===ano&&Number(m)-1===mes;});
  const usoMap={};fichasMes.forEach(f=>{const k=`${f.x}.${f.num}`;if(!usoMap[k])usoMap[k]={x:f.x,num:f.num,g:0,n:0};usoMap[k].g+=Number(f.g);usoMap[k].n++;});
  const lista=Object.entries(usoMap).map(([k,v])=>({k,...v,tubos:Math.ceil(v.g*1.5/60)})).sort((a,b)=>b.g-a.g);
  const totalG=lista.reduce((s,u)=>s+u.g,0);
  return(<>
    <div style={{background:"linear-gradient(135deg,#f5f3ff,#ede9fe)",borderRadius:12,padding:"14px 18px",marginBottom:16,border:"1px solid #ddd6fe"}}>
      <div style={{fontSize:13,fontWeight:700,color:"#7c3aed",marginBottom:4}}>💜 Compras de Coloração — {MESES[mes]}</div>
      <div style={{fontSize:11,color:"#888"}}>Calculado com base nas fichas técnicas. Sugestão com margem de 50%.</div>
    </div>
    {lista.length===0?<div className="empty"><div className="empty-i">💜</div><p>Nenhuma ficha em {MESES[mes]}.<br/>Adicione fichas técnicas nas clientes.</p></div>
     :<>
      <div className="g4" style={{marginBottom:14}}>
        <div className="stat"><div className="stat-l">Tons usados</div><div className="stat-v purple">{lista.length}</div></div>
        <div className="stat"><div className="stat-l">Gramas totais</div><div className="stat-v purple">{totalG}g</div></div>
        <div className="stat"><div className="stat-l">Tubos p/ comprar</div><div className="stat-v gold">{lista.reduce((s,u)=>s+u.tubos,0)}</div></div>
        <div className="stat"><div className="stat-l">Aplicações</div><div className="stat-v">{fichasMes.length}</div></div>
      </div>
      <div className="card"><div className="card-h"><span className="card-t">🛒 Lista de compras</span><button className="btn btn-ghost btn-xs" onClick={()=>navigator.clipboard?.writeText("Lista coloração Dicollore:\n"+lista.map(u=>`• ${u.x}.${u.num}: ${u.tubos} tubo(s) (~${Math.ceil(u.g*1.5)}g)`).join("\n"))}>📋 Copiar</button></div>
        <div className="card-b" style={{padding:"0 18px"}}>
          {lista.map(u=><div key={u.k} className="row">
            <div style={{width:22,height:22,borderRadius:"50%",background:"#b89060",border:"2px solid #ddd6fe",flexShrink:0}}/>
            <div style={{flex:1}}><div style={{fontWeight:600,fontSize:13}}>Dicollore {u.x}.{u.num}</div><div style={{fontSize:11,color:"#aaa"}}>Usado: {u.g}g em {u.n} aplicação{u.n>1?"ões":""}</div></div>
            <div style={{textAlign:"right"}}><div style={{fontWeight:700,fontSize:13,color:"#7c3aed"}}>{u.tubos} tubo{u.tubos>1?"s":""}</div><div style={{fontSize:11,color:"#aaa"}}>~{Math.ceil(u.g*1.5)}g</div></div>
          </div>)}
        </div>
      </div>
    </>}
  </>);
}


// ALERTAS — 30 minutos antes do atendimento
function useAlertas(apts, notify) {
  useEffect(() => {
    const verificar = () => {
      const agora = new Date();
      const hojeStr = `${agora.getFullYear()}-${s2(agora.getMonth()+1)}-${s2(agora.getDate())}`;
      const horaAtual = agora.getHours() * 60 + agora.getMinutes();

      apts.filter(a => a.data === hojeStr && a.status !== "cancelado" && !a.pago).forEach(a => {
        const [h, m] = (a.hora || "00:00").split(":").map(Number);
        const minApt = h * 60 + m;
        const diff = minApt - horaAtual;
        // Alerta entre 28 e 32 minutos antes
        if (diff >= 28 && diff <= 32) {
          notify(`⏰ Em 30 min: ${a.cliente} — ${a.servico} às ${a.hora}`, "wa");
        }
      });
    };

    verificar(); // roda imediatamente
    const interval = setInterval(verificar, 60000); // verifica a cada minuto
    return () => clearInterval(interval);
  }, [apts]);
}

// Painel de alertas do dia
function AlertasDia({apts}) {
  const agora = new Date();
  const hojeStr = `${agora.getFullYear()}-${s2(agora.getMonth()+1)}-${s2(agora.getDate())}`;
  const horaAtual = agora.getHours() * 60 + agora.getMinutes();

  const hojeApts = apts
    .filter(a => a.data === hojeStr && a.status !== "cancelado")
    .sort((a, b) => a.hora > b.hora ? 1 : -1);

  const getStatus = (hora) => {
    const [h, m] = hora.split(":").map(Number);
    const minApt = h * 60 + m;
    const diff = minApt - horaAtual;
    if (diff < 0) return { label: "Concluído", cor: "#aaa", bg: "#f5f5f5", icon: "✓" };
    if (diff <= 30) return { label: `Em ${diff}min`, cor: "#dc2626", bg: "#fef2f2", icon: "🔴" };
    if (diff <= 60) return { label: `Em ${diff}min`, cor: "#d97706", bg: "#fffbeb", icon: "🟡" };
    return { label: `Em ${Math.floor(diff/60)}h${diff%60>0?diff%60+"min":""}`, cor: "#16a34a", bg: "#f0fdf4", icon: "🟢" };
  };

  if (hojeApts.length === 0) {
    return (
      <div className="empty">
        <div className="empty-i">🌿</div>
        <p>Sem atendimentos hoje</p>
      </div>
    );
  }

  return (
    <div style={{display:"flex",flexDirection:"column",gap:10}}>
      {hojeApts.map(a => {
        const st = getStatus(a.hora);
        return (
          <div key={a.id} style={{background:"#fff",borderRadius:12,border:`1.5px solid ${st.cor}44`,padding:"14px 18px",display:"flex",alignItems:"center",gap:14}}>
            <div style={{width:44,height:44,borderRadius:"50%",background:st.bg,display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,flexShrink:0}}>
              {st.icon}
            </div>
            <div style={{flex:1}}>
              <div style={{fontWeight:700,fontSize:14}}>{a.hora} — {a.cliente}</div>
              <div style={{fontSize:12,color:"#888",marginTop:2}}>{a.servico}{a.troca?" · 🔄 Troca":""}{a.isPacote?` · Sessão ${a.sessao}`:""}</div>
              {a.pago && <div style={{fontSize:11,color:"#16a34a",fontWeight:600,marginTop:2}}>✓ Finalizado · R${a.total}</div>}
            </div>
            <div style={{textAlign:"right",flexShrink:0}}>
              <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:18,color:"#c9a96e",fontWeight:600}}>R${a.valor}</div>
              <div style={{fontSize:11,fontWeight:700,color:st.cor,marginTop:4,background:st.bg,padding:"2px 8px",borderRadius:8}}>{st.label}</div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

// PUBLIC PAGE
function PubPage({onBack,onNewApt}){
  const [tab,setTab]=useState("svc");const [catF,setCatF]=useState("todos");
  const [showBook,setShowBook]=useState(false);
  const [bf,setBf]=useState({nome:"",tel:"",svc:null,data:"",hora:""});
  const [done,setDone]=useState(false);
  const up=(k,v)=>setBf(p=>({...p,[k]:v}));
  const horarios=hs(bf.data);const ok=aberto(bf.data);
  const svcFilt=catF==="todos"?SERVICOS:SERVICOS.filter(s=>s.cat===catF);
  const CATS=[{id:"todos",l:"Todos"},{id:"corte",l:"Corte"},{id:"cor",l:"Cor"},{id:"trat",l:"Trat."},{id:"quim",l:"Química"},{id:"pacote",l:"Pacotes"}];
  const TABS=[{id:"svc",l:"Serviços"},{id:"pac",l:"Pacotes"},{id:"ag",l:"Agendar"},{id:"hor",l:"Horários"},{id:"cont",l:"Contato"},{id:"sobre",l:"Sobre"}];
  const DIAS_H=[["Terça","08h30–16h"],["Quarta","08h30–18h"],["Quinta","08h30–16h"],["Sexta","08h30–18h"],["Sábado","08h30–18h"]];
  const confirmar=()=>{const svcObj=SERVICOS.find(s=>s.nome===bf.svc);onNewApt({id:uid(),cliente:bf.nome,tel:bf.tel,servico:bf.svc,data:bf.data,hora:bf.hora,status:"pendente",valor:svcObj?.preco||0,bloq:svcObj?.bloq||90,pago:false,pgto:null,total:svcObj?.preco||0,troca:false,pacoteId:null,sessao:null,isPacote:false});setDone(true);};
  return(<div className="pub">
    <div className="pub-hero">
      <div className="pub-av">ER</div>
      <div className="pub-nome">Evelyn Ramos</div>
      <div className="pub-sub">Cabeleireira · Estúdio Madame</div>
      <div className="pub-bio"><strong style={{color:"#c9a96e"}}>Especialista em Alisamentos</strong> · Tratamentos de Nano Tecnologia<br/>Transformações personalizadas ✨ · São Carlos – SP</div>
      <div style={{display:"flex",gap:8,justifyContent:"center",flexWrap:"wrap"}}>
        <button className="pub-wa-btn" onClick={()=>openWA(WA_NUM,"Olá Evelyn! Vim pelo site e gostaria de agendar 🌸")}>💬 WhatsApp</button>
        <a className="pub-ig-btn" href={IG_URL} target="_blank" rel="noopener noreferrer">📸 {IG_HANDLE}</a>
      </div>
    </div>
    <div className="pub-tabs">{TABS.map(t=><button key={t.id} className={`pub-tab ${tab===t.id?"on":""}`} onClick={()=>setTab(t.id)}>{t.l}</button>)}</div>
    <div className="pub-sec">
      {tab==="svc"&&(<>
        <div className="pub-title">Serviços</div>
        <div style={{display:"flex",gap:5,overflowX:"auto",marginBottom:12,paddingBottom:4}}>
          {CATS.map(c=><button key={c.id} style={{padding:"5px 12px",borderRadius:20,border:"1px solid",borderColor:catF===c.id?"#c9a96e":"#2a2a2a",background:catF===c.id?"#c9a96e":"transparent",color:catF===c.id?"#fff":"#555",cursor:"pointer",whiteSpace:"nowrap",fontFamily:"'DM Sans',sans-serif",fontSize:11}} onClick={()=>setCatF(c.id)}>{c.l}</button>)}
        </div>
        {svcFilt.map(s=><div key={s.id} className="pub-svc">
          <div style={{display:"flex",alignItems:"flex-start",justifyContent:"space-between",gap:8,marginBottom:4}}>
            <div><div style={{fontSize:9,color:"#c9a96e",textTransform:"uppercase",letterSpacing:1,marginBottom:2}}>{s.emoji}</div><div style={{fontSize:13,fontWeight:600,color:"#fff"}}>{s.nome}</div></div>
            <span style={{fontFamily:"'Cormorant Garamond',serif",fontSize:20,color:"#c9a96e",fontWeight:600,whiteSpace:"nowrap"}}>R${s.preco}</span>
          </div>
          <div style={{fontSize:10,color:"#333",marginBottom:8}}>⏱ {s.dur}</div>
          <button className="pub-ag-btn" onClick={()=>{setBf(p=>({...p,svc:s.nome}));setShowBook(true);setDone(false);}}>Agendar este serviço</button>
        </div>)}
      </>)}
      {tab==="pac"&&(<>
        <div className="pub-title">Pacotes</div>
        <p style={{textAlign:"center",fontSize:12,color:"#555",marginBottom:14}}>Pague só na 1ª sessão! 🌸</p>
        {PACOTES.map(p=><div key={p.id} style={{background:"#161616",borderRadius:11,border:"1.5px solid #7c3aed44",padding:14,marginBottom:8}}>
          <div style={{display:"flex",alignItems:"flex-start",justifyContent:"space-between",gap:8,marginBottom:6}}>
            <div><div style={{fontSize:9,color:"#7c3aed",textTransform:"uppercase",letterSpacing:1,marginBottom:2}}>{p.emoji} Pacote</div><div style={{fontSize:13,fontWeight:600,color:"#fff"}}>{p.nome}</div></div>
            <span style={{fontFamily:"'Cormorant Garamond',serif",fontSize:20,color:"#c9a96e",fontWeight:600}}>R${p.preco}</span>
          </div>
          <div style={{fontSize:11,color:"#555",marginBottom:8}}>{p.sessoes} sessões · {p.semanal?"Mesmo dia toda semana":"Quinzenal"} · Paga só na 1ª</div>
          <button className="pub-ag-btn" style={{background:"linear-gradient(135deg,#7c3aed,#5b21b6)"}} onClick={()=>openWA(WA_NUM,`Olá Evelyn! Gostaria de contratar o pacote ${p.nome} 🌸`)}>Contratar pacote</button>
        </div>)}
      </>)}
      {tab==="ag"&&(<>
        <div className="pub-title">Agendar</div>
        <button className="pub-ag-btn" onClick={()=>{setShowBook(true);setDone(false);}}>💇‍♀️ Agendar horário</button>
        <div style={{marginTop:14,background:"#161616",borderRadius:11,padding:"12px 14px",border:"1px solid #1e1e1e",fontSize:11,color:"#555",lineHeight:2}}>📍 {ENDERECO_FULL}</div>
      </>)}
      {tab==="hor"&&(<>
        <div className="pub-title">Horários</div>
        {["Domingo","Segunda-feira","Terça-feira","Quarta-feira","Quinta-feira","Sexta-feira","Sábado"].map(d=>{const h=DIAS_H.find(([n])=>d.startsWith(n));return<div key={d} className="pub-hor"><span style={{fontSize:12,color:"#ccc",fontWeight:500}}>{d}</span>{h?<span style={{fontSize:12,color:"#c9a96e",fontWeight:600}}>{h[1]}</span>:<span style={{fontSize:11,color:"#333",fontStyle:"italic"}}>Fechado</span>}</div>;})}
        <div style={{marginTop:12,background:"#161616",borderRadius:9,padding:"11px 13px",fontSize:11,color:"#555",border:"1px solid #1e1e1e"}}>📍 {ENDERECO}</div>
      </>)}
      {tab==="cont"&&(<>
        <div className="pub-title">Contato</div>
        <a className="pub-link" href={IG_URL} target="_blank" rel="noopener noreferrer"><div style={{width:44,height:44,borderRadius:11,background:"linear-gradient(135deg,#f09433,#e6683c,#dc2743,#cc2366,#bc1888)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:19}}>📸</div><div><div style={{fontSize:14,fontWeight:600,color:"#fff"}}>{IG_HANDLE}</div><div style={{fontSize:10,color:"#444",marginTop:1}}>Instagram · 1.559 seguidores</div></div><div style={{color:"#333",marginLeft:"auto"}}>→</div></a>
        <div className="pub-link" onClick={()=>openWA(WA_NUM,"Olá Evelyn! Vim pelo site 🌸")}><div style={{width:44,height:44,borderRadius:11,background:"#25d366",display:"flex",alignItems:"center",justifyContent:"center",fontSize:19}}>💬</div><div><div style={{fontSize:14,fontWeight:600,color:"#fff"}}>WhatsApp</div><div style={{fontSize:10,color:"#444",marginTop:1}}>Fale diretamente comigo</div></div><div style={{color:"#333",marginLeft:"auto"}}>→</div></div>
        <a className="pub-link" href={MAAPP} target="_blank" rel="noopener noreferrer"><div style={{width:44,height:44,borderRadius:11,background:"linear-gradient(135deg,#c9a96e,#b8935a)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:19}}>🔗</div><div><div style={{fontSize:14,fontWeight:600,color:"#fff"}}>Agendamento Online</div><div style={{fontSize:10,color:"#444",marginTop:1}}>maapp.com.br/EvelynRamos</div></div><div style={{color:"#333",marginLeft:"auto"}}>→</div></a>
      </>)}
      {tab==="sobre"&&(<>
        <div className="pub-title">Sobre Mim</div>
        <div style={{background:"#161616",borderRadius:14,overflow:"hidden",border:"1px solid #1e1e1e"}}>
          <div style={{background:"linear-gradient(135deg,#1a1208,#2a1a08)",padding:"20px 18px",textAlign:"center"}}>
            <div style={{width:60,height:60,borderRadius:"50%",background:"linear-gradient(135deg,#c9a96e,#b8935a)",margin:"0 auto 10px",display:"flex",alignItems:"center",justifyContent:"center",fontFamily:"'Cormorant Garamond',serif",fontSize:20,color:"#fff"}}>ER</div>
            <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:22,color:"#c9a96e",marginBottom:3}}>Evelyn Ramos</div>
            <div style={{fontSize:10,color:"#888",letterSpacing:2,textTransform:"uppercase"}}>Cabeleireira · Estúdio Madame</div>
          </div>
          <div style={{padding:"16px"}}>
            <div style={{fontSize:12,color:"#888",lineHeight:1.9,marginBottom:14}}>Especialista em alisamentos e transformações personalizadas. Com mais de 6 anos de experiência, entrego resultados impecáveis com as melhores técnicas. 🌸</div>
            {[["✂️","Especialista em Alisamentos"],["🧴","Tratamentos de Nano Tecnologia"],["✨","Transformações personalizadas"],["👱","Loiro & Moreno Iluminado"],["📍","São Carlos – SP"]].map(([ic,tx])=><div key={tx} style={{display:"flex",alignItems:"center",gap:10,padding:"7px 10px",background:"#1a1a1a",borderRadius:8,border:"1px solid #222",marginBottom:5}}><span style={{fontSize:14}}>{ic}</span><span style={{fontSize:12,color:"#bbb"}}>{tx}</span></div>)}
            <div style={{marginTop:14,display:"flex",gap:8}}>
              <button className="pub-wa-btn" style={{flex:1,justifyContent:"center"}} onClick={()=>openWA(WA_NUM,"Olá Evelyn! Gostaria de agendar 🌸")}>💬 Agendar</button>
              <a className="pub-ig-btn" href={IG_URL} target="_blank" rel="noopener noreferrer" style={{flex:1,justifyContent:"center",textDecoration:"none"}}>📸 Instagram</a>
            </div>
          </div>
        </div>
      </>)}
    </div>
    <div style={{textAlign:"center",padding:"12px",borderTop:"1px solid #141414"}}><button onClick={onBack} style={{background:"none",border:"none",color:"#222",fontSize:10,cursor:"pointer",fontFamily:"'DM Sans',sans-serif"}}>🔐 Acesso restrito</button></div>
    {showBook&&<div className="pub-overlay" onClick={e=>e.target===e.currentTarget&&setShowBook(false)}>
      <div className="pub-modal">
        {done?<div style={{textAlign:"center",padding:"36px 18px"}}>
          <div style={{fontSize:48,marginBottom:12}}>✅</div>
          <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:22,color:"#c9a96e",marginBottom:6}}>Agendado!</div>
          <div style={{fontSize:12,color:"#666",marginBottom:16}}>Confirmação pelo WhatsApp em breve.<br/><strong style={{color:"#c9a96e"}}>{bf.svc}</strong> · {fD(bf.data)} às {bf.hora}</div>
          <button className="pub-ag-btn" onClick={()=>setShowBook(false)}>Fechar</button>
        </div>:<>
          <div style={{padding:"18px 18px 0",textAlign:"center"}}><div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:20,color:"#c9a96e",marginBottom:3}}>💇‍♀️ Agendar Horário</div><div style={{fontSize:11,color:"#555",marginBottom:14}}>Preencha os dados abaixo</div></div>
          <div style={{padding:"0 18px"}}>
            <div style={{marginBottom:10}}><label style={{display:"block",fontSize:10,fontWeight:700,textTransform:"uppercase",color:"#555",marginBottom:4}}>Seu nome</label><input className="pub-mi" value={bf.nome} onChange={e=>up("nome",e.target.value)} placeholder="Nome completo"/></div>
            <div style={{marginBottom:10}}><label style={{display:"block",fontSize:10,fontWeight:700,textTransform:"uppercase",color:"#555",marginBottom:4}}>WhatsApp</label><input className="pub-mi" value={bf.tel} onChange={e=>up("tel",e.target.value)} placeholder="16999999999"/></div>
            <div style={{marginBottom:10}}><label style={{display:"block",fontSize:10,fontWeight:700,textTransform:"uppercase",color:"#555",marginBottom:4}}>Serviço</label>
              <select className="pub-mi" value={bf.svc||""} onChange={e=>up("svc",e.target.value)}><option value="">Escolha...</option>{SERVICOS.map(s=><option key={s.id} value={s.nome}>{s.emoji} {s.nome} — R${s.preco}</option>)}</select>
            </div>
            <div style={{marginBottom:10}}><label style={{display:"block",fontSize:10,fontWeight:700,textTransform:"uppercase",color:"#555",marginBottom:4}}>Data</label><input type="date" className="pub-mi" value={bf.data} min={hj()} onChange={e=>up("data",e.target.value)}/></div>
            {bf.data&&!ok&&<div style={{background:"#1a0a0a",border:"1px solid #3a1a1a",borderRadius:8,padding:"9px 12px",fontSize:11,color:"#ef4444",marginBottom:10}}>⚠️ Fechado. Atendimento: ter–sáb.</div>}
            {bf.data&&ok&&<div style={{marginBottom:10}}><label style={{display:"block",fontSize:10,fontWeight:700,textTransform:"uppercase",color:"#555",marginBottom:4}}>Horário</label><div className="pub-t-grid">{horarios.map(h=><button key={h} className={`pub-t-btn ${bf.hora===h?"on":""}`} onClick={()=>up("hora",h)}>{h}</button>)}</div></div>}
          </div>
          <div style={{padding:"12px 18px 28px",display:"flex",gap:7}}>
            <button style={{flex:1,padding:10,border:"1px solid #2a2a2a",borderRadius:9,background:"transparent",color:"#666",fontFamily:"'DM Sans',sans-serif",fontSize:13,cursor:"pointer"}} onClick={()=>setShowBook(false)}>Cancelar</button>
            <button className="pub-ag-btn" style={{flex:2,marginTop:0,borderRadius:9,padding:10}} disabled={!bf.nome||!bf.tel||!bf.svc||!bf.hora||!ok} onClick={confirmar}>Confirmar ✓</button>
          </div>
        </>}
      </div>
    </div>}
  </div>);
}

// APP PRINCIPAL
export default function App(){
  const [tela,setTela]=useState(()=>{try{if(localStorage.getItem("er")==="1"||sessionStorage.getItem("er")==="1")return "admin";}catch(e){}return "login";});
  const [view,setView]=useState("dashboard");
  const [apts,setApts]=useState(agendamentosIniciais);
  const [clientes,setClientes]=useState(clientesIniciais);
  const [fichas,setFichas]=useState([]);
  const [stock,setStock]=useState(ESTOQUE_DEF);
  const [fichaCliente,setFichaCliente]=useState(null);
  const [showBook,setShowBook]=useState(false);
  const [showTroca,setShowTroca]=useState(false);
  const [selData,setSelData]=useState(null);
  const [toast,setToast]=useState(null);
  const notify=(msg,type="ok")=>setToast({msg,type});

  // Alertas automáticos 30min antes de cada atendimento
  useAlertas(apts, notify);

  const salvarApt=(apt,isPacoteDirect,waData)=>{
    setApts(p=>[...p,{...apt,waSent:true}]);setShowBook(false);
    if(apt.tel&&!isPacoteDirect){
      const svc=SERVICOS.find(s=>s.nome===apt.servico);
      setTimeout(()=>openWA(apt.tel,msgs.confirm(apt.cliente,apt.servico,fD(apt.data),apt.hora,apt.valor)),400);
      if(svc?.alis)setTimeout(()=>openWA(apt.tel,msgs.posAlis(apt.cliente,apt.servico)),2000);
      if(svc?.loiro)setTimeout(()=>openWA(apt.tel,msgs.posLoiro(apt.cliente)),2000);
    }
    if(isPacoteDirect&&waData&&apt.tel) setTimeout(()=>openWA(apt.tel,msgs.pacote(apt.cliente,waData.pac.nome,waData.datas)),400);
    notify("✓ Agendamento salvo!","wa");
  };
  const mudarStatus=(id,st)=>{setApts(p=>p.map(a=>a.id===id?{...a,status:st}:a));notify(st==="confirmado"?"✓ Confirmado!":"Cancelado.");};
  const sendWA=apt=>{openWA(apt.tel,msgs.confirm(apt.cliente,apt.servico,fD(apt.data),apt.hora,apt.valor));notify("📱 WhatsApp aberto!","wa");};
  const logout=()=>{try{localStorage.removeItem("er");sessionStorage.removeItem("er");}catch(e){}setTela("login");};

  const NAV=[
    {id:"dashboard",  icon:"🏠",l:"Início"},
    {id:"agenda",     icon:"📅",l:"Agenda"},
    {id:"alertas",    icon:"🔔",l:"Alertas Hoje"},
    {id:"atendimento",icon:"⏱", l:"Atendimento"},
    {id:"agendamentos",icon:"📋",l:"Agendas"},
    {id:"metas",      icon:"🎯",l:"Metas"},
    {id:"financeiro", icon:"💰",l:"Financeiro"},
    {id:"clientes",   icon:"👤",l:"Clientes"},
    {id:"mensagens",  icon:"💬",l:"Mensagens"},
    {id:"estoque",    icon:"💜",l:"Estoque"},
    {id:"compras",    icon:"🛒",l:"Compras"},
  ];
  const TITLES={dashboard:"Início",alertas:"Alertas do Dia 🔔",agenda:"Agenda",atendimento:"Atendimento ⏱",agendamentos:"Agendamentos",metas:"Metas & Captação 🎯",financeiro:"Financeiro 💰",clientes:"Clientes",mensagens:"Mensagens WhatsApp",estoque:"Estoque",compras:"Compras de Coloração 🛒"};
  const BOT=[{id:"dashboard",i:"🏠",l:"Início"},{id:"agenda",i:"📅",l:"Agenda"},{id:"alertas",i:"🔔",l:"Alertas"},{id:"metas",i:"🎯",l:"Metas"},{id:"clientes",i:"👤",l:"Clientes"}];
  const today=new Date().toLocaleDateString("pt-BR",{weekday:"long",day:"numeric",month:"long"});

  if(tela==="login") return <><style>{CSS}</style><Login onLogin={()=>setTela("admin")} onPub={()=>setTela("pub")}/></>;
  if(tela==="pub") return <><style>{CSS}</style><PubPage onBack={()=>setTela("login")} onNewApt={apt=>{setApts(p=>[...p,apt]);notify("🌸 Novo agendamento!");}} />{toast&&<Toast msg={toast.msg} type={toast.type} done={()=>setToast(null)}/>}</>;

  return(<>
    <style>{CSS}</style>
    <div className="app">
      <nav className="sidebar">
        <div className="sb-logo"><div className="sb-er">ER</div><div className="sb-sub">Estúdio Madame · 🔐</div></div>
        <div className="nav">{NAV.map(n=><div key={n.id} className={`ni ${view===n.id?"on":""}`} onClick={()=>setView(n.id)}><span style={{fontSize:14,width:18,textAlign:"center"}}>{n.icon}</span><span>{n.l}</span></div>)}</div>
        <div className="sb-foot">
          <button className="sb-pub" onClick={()=>setTela("pub")}>🌸 Página pública</button>
          <button className="sb-out" onClick={logout}>🔓 Sair</button>
        </div>
      </nav>
      <div className="main">
        <div className="topbar">
          <div><h2>{TITLES[view]||view}</h2><p>{today}</p></div>
          <div className="tbr">
            {apts.filter(a=>a.status==="pendente").length>0&&<div style={{background:"#fffbeb",border:"1px solid #fde68a",borderRadius:7,padding:"4px 10px",fontSize:11,color:"#d97706",fontWeight:500}}>⚠️ {apts.filter(a=>a.status==="pendente").length} pendente</div>}
            {(()=>{
              const agora=new Date();
              const hojeStr=`${agora.getFullYear()}-${s2(agora.getMonth()+1)}-${s2(agora.getDate())}`;
              const horaAtual=agora.getHours()*60+agora.getMinutes();
              const proximos=apts.filter(a=>{
                if(a.data!==hojeStr||a.status==="cancelado"||a.pago)return false;
                const[h,m]=(a.hora||"00:00").split(":").map(Number);
                const diff=h*60+m-horaAtual;
                return diff>0&&diff<=60;
              });
              if(proximos.length===0)return null;
              return <div style={{background:"#fef2f2",border:"1px solid #fecaca",borderRadius:7,padding:"4px 10px",fontSize:11,color:"#dc2626",fontWeight:600,cursor:"pointer"}} onClick={()=>setView("alertas")}>🔔 {proximos.length} em breve!</div>;
            })()}
            {(view==="dashboard"||view==="agendamentos")&&<button className="btn btn-gold btn-sm" onClick={()=>{setSelData(null);setShowBook(true);}}>+ Novo</button>}
            {(view==="dashboard"||view==="agendamentos")&&<button className="btn btn-sm btn-green" onClick={()=>setShowTroca(true)}>🔄 Troca</button>}
            <button className="btn btn-ghost btn-sm" onClick={()=>setTela("pub")}>🌸 Pág. pública</button>
          </div>
        </div>
        <div className="content">
          {view==="dashboard"    &&<Dashboard apts={apts} clientes={clientes} onNew={()=>{setSelData(null);setShowBook(true);}} onWA={sendWA} notify={notify}/>}
          {view==="agenda"       &&<AgendaView apts={apts} onNew={d=>{setSelData(d);setShowBook(true);}}/>}
          {view==="alertas"      &&<AlertasDia apts={apts}/>}
          {view==="atendimento"  &&<AtendimentoView apts={apts} setApts={setApts} stock={stock} setStock={setStock} notify={notify}/>}
          {view==="agendamentos" &&<AgendamentosView apts={apts} onSt={mudarStatus} onNew={()=>{setSelData(null);setShowBook(true);}} onWA={sendWA} onFicha={c=>setFichaCliente(c)}/>}
          {view==="metas"        &&<MetasView apts={apts} clientes={clientes} notify={notify}/>}
          {view==="financeiro"   &&<FinanceiroView apts={apts}/>}
          {view==="clientes"     &&<ClientesView apts={apts} clientes={clientes} setClientes={setClientes} fichas={fichas} notify={notify} onFicha={c=>setFichaCliente(c)}/>}
          {view==="mensagens"    &&<MensagensView/>}
          {view==="estoque"      &&<EstoqueView stock={stock} setStock={setStock}/>}
          {view==="compras"      &&<ComprasView fichas={fichas}/>}
        </div>
      </div>
    </div>
    <nav className="bot-nav" style={{display:"none"}}>
      {BOT.map(n=><button key={n.id} className={`bot-ni ${view===n.id?"on":""}`} onClick={()=>setView(n.id)}><span className="bot-ni-i">{n.i}</span><span className="bot-ni-l">{n.l}</span></button>)}
    </nav>
    {showBook&&<BookingModal onClose={()=>setShowBook(false)} onSave={salvarApt} dataInicio={selData} apts={apts}/>}
    {showTroca&&<TrocaModal onClose={()=>setShowTroca(false)} onSave={apt=>{setApts(p=>[...p,apt]);setShowTroca(false);notify("🔄 Troca agendada!");}} apts={apts}/>}
    {fichaCliente&&<FichaModal cliente={fichaCliente} fichas={fichas} onSave={f=>{setFichas(p=>[...p,f]);notify(`💜 Ficha salva! Dicollore ${f.x}.${f.num}`,"p");}} onClose={()=>setFichaCliente(null)}/>}
    {toast&&<Toast msg={toast.msg} type={toast.type} done={()=>setToast(null)}/>}
  </>);
}
